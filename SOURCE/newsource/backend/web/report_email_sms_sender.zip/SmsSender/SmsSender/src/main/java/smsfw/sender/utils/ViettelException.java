/**
 * Copyright 2011 Viettel Telecom. All rights reserved.
 * VIETTEL PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package smsfw.sender.utils;

/**
 * Exception
 * 
 * @author: TungTT
 * @version: 1.0
 * @since:  01-03-2011
 */
public class ViettelException extends Exception {

    private static final long serialVersionUID = -777216335204861186L;

    public ViettelException() {
    }

    public ViettelException(String s) {
        super(s);
    }

    public ViettelException(Throwable cause) {
        super(cause);
    }

    public ViettelException(String message, Throwable cause) {
        super(message, cause);
    }
}
