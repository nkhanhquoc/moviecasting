/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smsfw.sender.database;

import com.viettel.pool.connection.OracleConnection;
import com.viettel.pool.connection.TimestenConnection;
import com.viettel.cluster.agent.integration.Record;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.apache.log4j.Logger;
import smsfw.sender.manager.AppManager;
import smsfw.sender.utils.MtRecord;
import smsfw.sender.utils.TimeToRun;

/**
 * @see GetConnection
 * @author THANHNV75
 */
public class DbAdapter {

	private static final Logger logger = Logger.getLogger(DbAdapter.class);
	private TimestenConnection connection;
	private int dbRetry;
	private static final String SQL_INSERT_MT_HIS = "insert into sms_mt_his(mo_his_id, msisdn, message, sent_time,"
		+ " status,channel,node_name,cluster_name,receive_time, is_spam, retry_sent_count, app_id) "
		+ "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	private static final String SQL_DELETE_MT = "delete from sms_mt where id = ?";
	private static final String SQL_CHECK_CONNECTION = "select 1 as data from dual";
	private static final String SQL_UPDATE_RETRY = "update sms_mt set retry_sent_count = retry_sent_count+1 where id = ?";

	private static int queryTimeout = 30000; // Time out query
	private static int timeBreak = 0;
	private static DbAdapter instance;

	public static int getQueryTimeout() {
		return queryTimeout;
	}

	public static void setQueryTimeout(int queryTimeout) {
		DbAdapter.queryTimeout = queryTimeout;
	}

	public static int getTimeBreak() {
		return timeBreak;
	}

	public static void setTimeBreak(int timeBreak) {
		DbAdapter.timeBreak = timeBreak;
	}

	public static DbAdapter getInstance() {
		if (instance == null) {
			logger.error("Datasource must be initialized!");
		}
		return instance;
	}

	private DbAdapter(String configPath, int dbRetry) {
		try {
			this.connection = (TimestenConnection) OracleConnection.getInstance(configPath);
			this.dbRetry = dbRetry;
		} catch (Exception e) {
			logger.error("Initialize database connection failed.", e);
		}
	}

	public static void init(String configPath, Integer dbRetry) {
		synchronized (DbAdapter.class) {
			if (instance != null) {
				return;
			}
			instance = new DbAdapter(configPath, dbRetry);
		}
	}

	/**
	 * Update retry number when sender error
	 *
	 * @param listMt
	 * @return
	 */
	public int[] updateRetry(List<MtRecord> listMt) {
		int[] result = null;
		int retry = 0;

		while (null == result && retry <= this.dbRetry) {
			if (retry > 0) {
				logger.info("updateRetry retry " + retry);
			}
			result = this.pUpdateRetry(listMt);
			retry++;
		}
		return result;
	}

	/**
	 * update product code of subscriber
	 *
	 * @param listSubscriber list subscriber to update
	 * @return null if update error else return array record updated
	 */
	private int[] pUpdateRetry(List<MtRecord> listMt) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet set = null;
		int[] result;

		try {
			conn = this.connection.getConnection();
			if (null == conn) {
				logger.error("pUpdateRetry get connection null");
				return null;
			}
			stmt = this.connection.getPrepared(conn, SQL_UPDATE_RETRY);
			conn.setAutoCommit(false);
			for (MtRecord mtRecord : listMt) {
				stmt.setLong(1, mtRecord.getID());
				stmt.addBatch();
			}
			result = stmt.executeBatch();
			conn.commit();
//			conn.commit();
			logger.info("update retry successful with: " + listMt.size());
			return result;
		} catch (Exception ex) {
			logger.error("pUpdateRetry error", ex);
			return null;
		} finally {
			this.connection.close(set, "pUpdateRetry");
			this.connection.close(stmt, "pUpdateRetry");
			this.connection.close(conn, "pUpdateRetry");

		}
	}

	public int[] deleteMt(List<Long> listMtId) {
		int[] result = null;
		int retry = 0;

		while (null == result && retry <= this.dbRetry) {
			if (retry > 0) {
				logger.info("deleteMt retry " + retry);
			}
			result = this.pDeleteMt(listMtId);
			retry++;
		}
		return result;
	}

	private int[] pDeleteMt(List<Long> listMtId) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet set = null;
		int[] result;

		try {
			conn = this.connection.getConnection();
			if (null == conn) {
				logger.error("pDeleteMt get connection null");
				return null;
			}
			stmt = this.connection.getPrepared(conn, SQL_DELETE_MT);
			conn.setAutoCommit(false);
			for (Long mtId : listMtId) {
				stmt.setLong(1, mtId);
				stmt.addBatch();
			}
			result = stmt.executeBatch();
			conn.commit();
			logger.info("delete " + listMtId.size() + " message from MT");
//			conn.commit();
			return result;
		} catch (Exception ex) {
			logger.error("pDeleteMt error", ex);
			return null;
		} finally {
			this.connection.close(set, "pDeleteMt");
			this.connection.close(stmt, "pDeleteMt");
			this.connection.close(conn, "pDeleteMt");
		}
	}

	public int[] insertMtHis(List<MtRecord> listMt, String nodeName, String clusterName) {
		int[] result = null;
		int retry = 0;

		while (null == result && retry <= this.dbRetry) {
			if (retry > 0) {
				logger.info("insertMtHis retry " + retry);
			}
			result = this.pInsertMtHis(listMt, nodeName, clusterName);
			retry++;
		}
		return result;
	}

	public int[] pInsertMtHis(List<MtRecord> listMt, String nodeName, String clusterName) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet set = null;
		int[] result;
		try {
			conn = this.connection.getConnection();
			if (null == conn) {
				logger.error("pInsertMtHis get connection null");
				return null;
			}
			stmt = this.connection.getPrepared(conn, SQL_INSERT_MT_HIS);
			conn.setAutoCommit(false);
			for (MtRecord mtRecord : listMt) {
//				stmt.setLong(1, mtRecord.getID());
				stmt.setLong(1, mtRecord.getMoHisId());
				stmt.setString(2, mtRecord.getMsisdn());
				stmt.setString(3, mtRecord.getMessage());
				stmt.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
				stmt.setInt(5, mtRecord.getStatus());
				stmt.setString(6, mtRecord.getChannel());
				stmt.setString(7, nodeName);
				stmt.setString(8, clusterName);
				stmt.setTimestamp(9, mtRecord.getReceiveTime());
				stmt.setInt(10, mtRecord.getIsSpam());
				stmt.setInt(11, mtRecord.getRetryNum());
				stmt.setString(12, mtRecord.getAppId());
				stmt.addBatch();
			}
			result = stmt.executeBatch();
			conn.commit();
			logger.info("insert " + listMt.size() + " record in MT_HIS");
//			conn.commit();
			return result;
		} catch (Exception ex) {
			logger.error("pInsertMtHis error", ex);
			return null;
		} finally {
			this.connection.close(set, "pInsertMtHis");
			this.connection.close(stmt, "pInsertMtHis");
			this.connection.close(conn, "pInsertMtHis");
		}

	}

	private Date parseDate(String date) {

		try {
			SimpleDateFormat inputParser = new SimpleDateFormat("HH:mm", Locale.US);
			return inputParser.parse(date);
		} catch (java.text.ParseException e) {
			logger.error("error parseDate: ", e);
			return new Date(0);
		}
	}

	private boolean validateTimeToRun(List<TimeToRun> lstTimeToRun) {
		Date date;
		Calendar now = Calendar.getInstance();
		int hour = now.get(Calendar.HOUR_OF_DAY);
		int minute = now.get(Calendar.MINUTE);
		date = parseDate(hour + ":" + minute);
		if (lstTimeToRun.size() > 0) {
			for (TimeToRun time : lstTimeToRun) {
				if (time.getStartTime().before(date) && time.getEndTime().after(date)) {
					return true;
				}
			}
		}

		return false;
	}

	public List<Record> getRecords(String sqlMt) {
		ResultSet rs = null;
		PreparedStatement pre = null;
		Connection conn = null;
		List<Record> lst = new ArrayList<Record>();
		//yada yada
		try {
			conn = this.connection.getConnection();
			if (conn == null) {
				logger.error("Conection is null");
				return null;
			}
			pre = this.connection.getPrepared(conn, sqlMt);
			rs = pre.executeQuery();
			while (rs.next()) {
				MtRecord mtRecord = null;
				//check is_spam
				int isSpam = rs.getInt(MtRecord.IS_SPAM);
				if (isSpam == 1) {
					//check time to send sms
					//check current time to send SMS

					String sendTime = AppManager.getSendTime();
					String[] arrTime = sendTime.split("[|]");
					List<TimeToRun> lstTimeToRun = new ArrayList<>();

					if (arrTime.length > 1) {
						for (String a : arrTime) {
							String[] arrTimeSub = a.split("[-]");

							TimeToRun timeToRun = new TimeToRun();
							timeToRun.setStartTime(parseDate(arrTimeSub[0]));
							timeToRun.setEndTime(parseDate(arrTimeSub[1]));
							lstTimeToRun.add(timeToRun);
						}
					} else {
						String[] arrTimeSub = sendTime.split("[-]");
						TimeToRun timeToRun = new TimeToRun();
						timeToRun.setStartTime(parseDate(arrTimeSub[0]));
						timeToRun.setEndTime(parseDate(arrTimeSub[1]));
						lstTimeToRun.add(timeToRun);
					}
					if (validateTimeToRun(lstTimeToRun)) {
						try {
							mtRecord = new MtRecord();
							mtRecord.setIdMt(rs.getLong(MtRecord.ID_DB));
							mtRecord.setMoHisId(rs.getLong(MtRecord.MO_HIS_ID));
							mtRecord.setMsisdn(rs.getString(MtRecord.MSISDN_DB));
							mtRecord.setMessage(rs.getString(MtRecord.MESSAGE_DB));
							mtRecord.setRetryNum(rs.getInt(MtRecord.RETRY_SENT_COUNT));
							mtRecord.setChannel(rs.getString(MtRecord.CHANNEL_DB));
							mtRecord.setReceiveTime(rs.getTimestamp(MtRecord.RECEIVE_TIME));
							mtRecord.setIsSpam(rs.getInt(MtRecord.IS_SPAM));
							mtRecord.setAppId(rs.getString(MtRecord.APP_ID));
						} catch (Exception ex) {
							logger.error("GET MT error: ", ex);
							mtRecord = null;
						}
					}
				} else {
					try {
						mtRecord = new MtRecord();
						mtRecord.setIdMt(rs.getLong(MtRecord.ID_DB));
						mtRecord.setMoHisId(rs.getLong(MtRecord.MO_HIS_ID));
						mtRecord.setMsisdn(rs.getString(MtRecord.MSISDN_DB));
						mtRecord.setMessage(rs.getString(MtRecord.MESSAGE_DB));
						mtRecord.setRetryNum(rs.getInt(MtRecord.RETRY_SENT_COUNT));
						mtRecord.setChannel(rs.getString(MtRecord.CHANNEL_DB));
						mtRecord.setReceiveTime(rs.getTimestamp(MtRecord.RECEIVE_TIME));
						mtRecord.setIsSpam(rs.getInt(MtRecord.IS_SPAM));
						mtRecord.setAppId(rs.getString(MtRecord.APP_ID));
					} catch (Exception ex) {
						logger.error("GET MT error: ", ex);
						mtRecord = null;
					}
				}

				if (mtRecord != null) {
					lst.add(mtRecord);
				}
			}
		} catch (Exception ex) {
			logger.error("ERROR: ", ex);
		} finally {
			this.connection.close(rs, "getRecords");
			this.connection.close(pre, "getRecords");
			this.connection.close(conn, "getRecords");
		}
		return lst;
	}

	public int CheckDatabase() {
		ResultSet rs = null;
		PreparedStatement pre = null;
		Connection conn = null;
		try {
			conn = this.connection.getConnection();
			if (conn == null) {
				return 0;
			}
			pre = this.connection.getPrepared(conn, SQL_CHECK_CONNECTION);
			rs = pre.executeQuery();
			int data = -1;
			while (rs.next()) {
				data = rs.getInt("DATA");
				break;
			}
			if (data != -1) {
				return 1;
			}
			return 0;
		} catch (SQLException ex) {
			logger.error("ERROR CHECK DB ", ex);
		} catch (Exception ex) {
			logger.error("ERROR CHECK DB ", ex);
		} finally {
			this.connection.close(rs, "checkDatabase");
			this.connection.close(pre, "checkDatabase");
			this.connection.close(conn, "checkDatabase");
		}
		return 0;
	}
	
}
