/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smsfw.sender.log.mtHis;

import org.apache.log4j.Logger;

/**
 *
 * @author THANHNV75
 */
public class InsertMtHisError {
    public static final Logger logger = Logger.getLogger(InsertMtHisError.class);
}
