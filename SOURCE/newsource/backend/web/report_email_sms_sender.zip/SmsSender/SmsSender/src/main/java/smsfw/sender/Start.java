/*
 * Copyright 2011 Viettel Telecom. All rights reserved.
 * VIETTEL PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package smsfw.sender;

import org.apache.log4j.PropertyConfigurator;

/**
 * Start
 * @author TungTT
 * @version 1.0
 * @since 01-03-2011
 */
public class Start {

    public static void main(String[] args) throws Exception {
         PropertyConfigurator.configure("../etc/log.conf");
        // Khoi dong MoProcess
        ScanProcessManager.getInstance().start();
        
    }
}
