/*
 * Copyright 2011 Viettel Telecom. All rights reserved.
 * VIETTEL PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package smsfw.sender.utils;

import com.viettel.cluster.agent.integration.Record;
import java.sql.Timestamp;

/**
 * Thong tin ban ghi MT
 * @author TungTT
 * @version 1.0
 * @since 01-03-2011
 */
public class MtRecord implements Record {

    public static final String ID_DB = "id";
    public static final String MO_HIS_ID = "mo_his_id";
    public static final String MSISDN_DB = "msisdn";
    public static final String MESSAGE_DB = "message";
    public static final String RETRY_SENT_COUNT = "retry_sent_count";
    public static final String CHANNEL_DB = "channel";
    public static final String RECEIVE_TIME = "receive_time";
    public static final String APP_ID = "app_id";
	public static final String IS_SPAM= "is_spam";
    //
    private long idMt;
    private long moHisId;
    private String msisdn;
    private String message;
    private int retryNum;
    private String channel;
    private int status;
    private Timestamp receiveTime;
    private String appId;
	private int isSpam;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public long getID() {
        return idMt;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public long getIdMt() {
        return idMt;
    }

    public void setIdMt(long idMt) {
        this.idMt = idMt;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public long getMoHisId() {
        return moHisId;
    }

    public void setMoHisId(long moHisId) {
        this.moHisId = moHisId;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public int getRetryNum() {
        return retryNum;
    }

    public void setRetryNum(int retryNum) {
        this.retryNum = retryNum;
    }

    public Timestamp getReceiveTime() {
        return receiveTime;
    }

    public void setReceiveTime(Timestamp receiveTime) {
        this.receiveTime = receiveTime;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    @Override
    public String toString() {
		StringBuilder sb= new StringBuilder("\n\tInput: ");
		sb.append("ID: ");
		sb.append(idMt);
		sb.append("|");
		sb.append("MSISDN: ");
		sb.append(msisdn);
		sb.append("|");
		sb.append("MESSAGE: ");
		sb.append(message);
		sb.append("|");
		sb.append("IS_SPAM: ");
		sb.append(isSpam);
		sb.append("|");
		sb.append("\n");
        return sb.toString();
    }

	public int getIsSpam() {
		return isSpam;
	}

	public void setIsSpam(int isSpam) {
		this.isSpam = isSpam;
	}
    
	
}
