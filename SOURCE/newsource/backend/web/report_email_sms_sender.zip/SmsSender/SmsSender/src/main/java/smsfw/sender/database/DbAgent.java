/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package smsfw.sender.database;

import com.viettel.cluster.agent.integration.DbProcessor;
import com.viettel.cluster.agent.integration.Record;
import java.sql.ResultSet;
import java.util.List;
import org.apache.log4j.Logger;
import static smsfw.sender.database.DbAdapter.getTimeBreak;

/**
 * Database using with agent
 *
 * @author thanhnv75
 */
public class DbAgent implements DbProcessor {

    private static final Logger logger = Logger.getLogger(DbAgent.class);
    private String sqlMt = "";
    private long timeSt;

    @Override
    public void setStatement(String sqlMt) {
        this.sqlMt = sqlMt;
    }

    @Override
    public String getStatement() {
        return this.sqlMt;
    }

    @Override
    public void updateStatement(String sqlMo) {
        this.sqlMt = sqlMo;
    }

    @Override
    public int updateProcessedRecord(List<Long> list) {
        return 0;
    }

    @Override
    public Record parse(ResultSet rs) {
        return null;
    }

    @Override
    public List<Record> getRecords() {
        if (sqlMt != null && sqlMt.trim().length() > 0) {
            return DbAdapter.getInstance().getRecords(sqlMt);
        } else {
            logger.info("SQL select MO is empty");
        }
        return null;
    }

    @Override
    public void processTimeoutRecord(List<Long> list) {
        timeSt = System.currentTimeMillis();
        while (DbAdapter.getInstance().deleteMt(list) == null) {
            if (getTimeBreak() <= 0 || (System.currentTimeMillis() - timeSt) > getTimeBreak()) {
                break;
            }
            try {
                Thread.sleep(300);
            } catch (Exception ex) {
                logger.error("ERROR:", ex);
            }
        }
    }


    @Override
    public int checkDatabase() {
       
       return DbAdapter.getInstance().CheckDatabase();
    }
}
