/*
 * Copyright 2011 Viettel Telecom. All rights reserved.
 * VIETTEL PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package smsfw.sender;

import com.viettel.cluster.agent.Dispatcher;
import com.viettel.cluster.agent.integration.Record;
import com.viettel.cluster.agent.utils.ConfigHolder;
import com.viettel.cluster.agent.utils.ConfigLoader;
import smsfw.sender.utils.SmsSender;
import smsfw.sender.utils.MtRecord;
import com.viettel.mmserver.base.ProcessThreadMX;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.management.NotCompliantMBeanException;
import org.apache.log4j.Logger;
import smsfw.sender.database.DbAdapter;
import smsfw.sender.database.DbAgent;
import smsfw.sender.manager.AppManager;

/**
 * Gui tin nhan tu MT cho khach hang
 *
 * @author TungTT
 * @version 1.0
 * @since 01-03-2011
 */
public class ProcessMt extends ProcessThreadMX {

//    private DbProcessorFW db;
//    private SmsSender sender;
	private String loggerLabel = ProcessMt.class.getSimpleName() + ": ";
	// LBF
	private Dispatcher dispatcher;
	protected ConfigHolder holder;
	protected String agentId;
	protected Logger disLogger;
	private long timeStart;
	private StringBuilder br = new StringBuilder();
	public static final int STATUS_SUCCESS = 1;
	public static final int STATUS_FAIL = 0;

	public ProcessMt(String threadName, int moduleId) throws NotCompliantMBeanException, IOException, SQLException, Exception {
		super(threadName);
		// Dang ky Log
		registerAgent(AppManager.getAppId() + ":type=" + ProcessMtManager.name + ",name=" + threadName);

		agentId = AppManager.getListAgent().get(moduleId);
		if (ConfigLoader.getInstance() == null) {
			ConfigLoader.createInstance("../etc/agent.cfg");
		}

		this.dispatcher = Dispatcher.getInstance(agentId);

		if (null == this.dispatcher) {
			this.dispatcher = Dispatcher.createInstance(new DbAgent(), agentId, logger);
		}
		logger.info("dispatcher.nember===========" + dispatcher.getMembers());

		holder = ConfigLoader.getInstance().getConfigHolder(agentId);
	}

	@Override
	public final void process() {
		buStartTime = new Date();
		List<Record> listRecords = null;
		List<MtRecord> listMt = null;
		List<MtRecord> listSucc = new ArrayList<MtRecord>();
		List<MtRecord> listFail = new ArrayList<MtRecord>();

		try {
			// Lay ban ghi trong MT
			while (listRecords == null) {
				listRecords = dispatcher.getRecords(AppManager.getMaxRow());
			}

			timeStart = System.currentTimeMillis();
			if (listRecords.size() > 0) {
				// Process
				listMt = new ArrayList<MtRecord>();
				for (Record record : listRecords) {
					listMt.add((MtRecord) record);
				}
				listRecords.clear();

				br.setLength(0);
				br.append(loggerLabel);
				br.setLength(0);
				br.append("\r\n").
					append("|\tMT_ID\t|").
					append("|\tMSISDN\t|").
					append("|\tMO_HIS_ID\t|\r\n");

				for (MtRecord moRecord : listMt) {
					br.append("|\t").
						append(moRecord.getIdMt()).
						append("\t|\t").
						append(moRecord.getMsisdn()).
						append("\t|\t").
						append(moRecord.getMoHisId()).
						append("\t|\r\n");
				}
				logger.info(br);

				List<Long> listMtIdInput = new ArrayList<Long>();
				for (MtRecord moRecord : listMt) {
					listMtIdInput.add(moRecord.getIdMt());
				}

				try {
					//1. process
					for (MtRecord mtRecord : listMt) {
						if (mtRecord.getRetryNum() < AppManager.getRetrySentCount()) {
							// Xu ly gui tin nhan
							String message = mtRecord.getMessage();
							if (message == null || message.trim().length() == 0) {
								logger.warn(loggerLabel + new Date() + "\nMessage is null: MSISDN=" + mtRecord.getMsisdn());
								listSucc.add(mtRecord);
								continue;
							}
							if (!isMSISDN(mtRecord.getMsisdn())) {
								logger.error(loggerLabel + "Send sms FAIL with MSISDN: \"" + mtRecord.getMsisdn()
									+ "\" Wrong format; please check again in config file!");
								mtRecord.setStatus(2);
								listSucc.add(mtRecord);
							} else {
								String msisdnFormat = formatMsisdn(mtRecord.getMsisdn());
								mtRecord.setMsisdn(msisdnFormat);
								String msg[] = message.split("\\^");
								int sendCount = 0;
								for (String msgSend : msg) {
									if (msgSend.trim().length() > 0) {
										int result = SmsSender.getInstance().sendSmsAll(msgSend, mtRecord.getMsisdn(),
											mtRecord.getChannel(), logger);
										if (result == 0) {
											sendCount++;
										}
									}
								}
								if (sendCount > 0) {
									logger.info(loggerLabel + "Send sms: \"" + message
										+ "\" to " + mtRecord.getMsisdn() + " sucess");
									mtRecord.setStatus(0);
									listSucc.add(mtRecord);
								} else {
									// Update retry_count= retry_count+1 ; khi tat ca cac tin nhan gui that bai
									logger.info(loggerLabel + "Send sms: \"" + message
										+ "\" to " + mtRecord.getMsisdn() + " fail: " + mtRecord.getRetryNum());
									listFail.add(mtRecord);
								}
							}

						} else {
							// Qua so lan retry => add de xoa
							mtRecord.setStatus(1);
							listSucc.add(mtRecord);
						}
					}

					//2. update retry when send error
					if (listFail.size() > 0) {
						if (DbAdapter.getInstance().updateRetry(listFail) == null) {
							br.setLength(0);
							br.append(loggerLabel).
								append("BREAK UPDATE RETRY_NUM table MT ==> ERROR DATABASE ==> NOT PROCESS CONTINOUS\n").
								append(listMt.toString());
							logger.error(br);
							// update retry fail => return ko xu ly
							return;
						}
					}

					//ID MT
					List<Long> listMtId = new ArrayList<Long>();
					for (MtRecord moRecord : listSucc) {
						listMtId.add(moRecord.getIdMt());
					}
					//3. delete mt
					if (DbAdapter.getInstance().deleteMt(listMtId) == null) {
						br.setLength(0);
						br.append(loggerLabel).
							append("BREAK DELETE MT ==> ERROR DATABASE ==> NOT PROCESS CONTINOUS\n").
							append(listMt.toString());
						logger.error(br);
						return;
					}

					// Remove khoi queue Dispatcher
					dispatcher.updateProcessedRecord(listMtIdInput);

					//4. insert mt_his
					if (listSucc.size() > 0) {
						if (DbAdapter.getInstance().insertMtHis(listSucc, holder.getNodeName(), holder.getClusterName()) == null) {
							br.setLength(0);
							br.append(loggerLabel).
								append("BREAK INSERT MT_HIS ==> ERROR DATABASE\n").
								append(listMt.toString());
							logger.error(br);
						}
						try {
							Thread.sleep(300);
						} catch (Exception ex) {
							logger.error("error to sleep: ", ex);
						}
					}

					br.setLength(0);
					br.append(loggerLabel).
						append("Total time to process ").
						append(listMt.size()).
						append(" requests: ").
						append((System.currentTimeMillis() - timeStart)).
						append(" ms\n").
						append(listMt.toString());
					logger.info(br);
					listMt.clear();
					listFail.clear();
					listSucc.clear();
				} catch (Exception ex) {
					buStartTime = null;
					br.setLength(0);
					br.append(loggerLabel).
						append(new Date()).
						append("\nERROR when send message:\n").
						append(listMt);
					logger.error(br, ex);
				}
			} else {
				// Khong con ban ghi nao trong MO => Sleep
				buStartTime = null;
				try {
					Thread.sleep(AppManager.getTimeSleep());
				} catch (InterruptedException ex) {
					logger.error(loggerLabel + "ERROR Sleep Thread", ex);
				}
			}
		} catch (Exception ex) {
			buStartTime = null;
			br.setLength(0);
			br.append(loggerLabel).
				append(new Date()).
				append("\nERROR process:\n").
				append(listMt);
			logger.error(br, ex);
		}
	}

	private boolean isMSISDN(String msisdn) {
		String msisdnParttern = AppManager.getMsisdnPattern();
		return msisdn.matches(msisdnParttern);
	}

	private String formatMsisdn(String msisdn) {
		if (msisdn != null) {
			if (msisdn.startsWith("+")) {
				msisdn = msisdn.substring(1, msisdn.length());
			}
			if (msisdn.startsWith("00")) {
				msisdn = msisdn.substring(2, msisdn.length());
			}
			if (msisdn.startsWith(AppManager.getCountryCode())) {
				msisdn = msisdn.substring(AppManager.getCountryCode().length(), msisdn.length());
			}
		}
		return msisdn;
	}
}
