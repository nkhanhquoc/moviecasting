/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.vmu.report;

import com.viettel.vmu.report.config.Config;
import com.viettel.vmu.report.dao.ReportProcessor;
import com.viettel.vmu.report.model.DailyRevenueReport;
import com.viettel.vmu.report.model.EmailSendQueue;
import com.viettel.vmu.report.model.ReportContents;
import com.viettel.vmu.report.model.SmsMt;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;

/**
 * Thuc hien ghi report vao DB
 *
 * @author NGHIALD
 */
public class CoreBusiness {

	private static final Logger logger = Logger.getLogger(CoreBusiness.class);
	private static final DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	private ReportProcessor dao;
	private Config config;
	private int batchSize = 100;
	private String regexString = "\\{\\{([\\s\\S]*)\\}\\}";
	private long lastInsertTime = 0L;

	public void setDao(ReportProcessor dao) {
		this.dao = dao;
	}

	public void setConfig(Config config) {
		this.config = config;
	}

	public void setBatchSize(int batchSize) {
		this.batchSize = batchSize;
	}

	public void setSysConfigCore() {
		logger.info("Start load sys config to hash");
		config.setSysConfig(dao.getSysConfig());
	}

	/**
	 * Insert cac ban ghi da tong hop vao DB theo batch
	 *
	 * @author NghiaLD <nghiald@viettel.com>
	 * @param list
	 * @created_at: 7/25/16 2:12 PM
	 */
	public void insertReport(List<DailyRevenueReport> list) {
		long startInsert = System.currentTimeMillis();
		logger.info("Start insert report|" + list.size());
		ArrayList<DailyRevenueReport> reports = new ArrayList<>();
		for (DailyRevenueReport rp : list) {
			reports.add(rp);
			if (reports.size() > batchSize) {
				try {
					long start = System.currentTimeMillis();
					dao.insertBatchDailyRevenueReport(reports);
					logger.info("Timeprocess|CoreBusiness|InsertBatch|DailyRevenueReport|" + reports.size() + "|" + (System.currentTimeMillis() - start));
					reports.clear();
				} catch (Exception e) {
					logger.error("Insert batcc DailyRevenueReport error", e);
				}
			}
		}
		//insert nhung ban ghi ngoai block batch
		if (reports.size() > 0) {
			try {
				long start = System.currentTimeMillis();
				dao.insertBatchDailyRevenueReport(reports);
				logger.info("Timeprocess|CoreBusiness|InsertBatch|DailyRevenueReport|" + reports.size() + "|" + (System.currentTimeMillis() - start));
				reports.clear();
			} catch (Exception e) {
				logger.error("Insert batcc DailyRevenueReport error", e);
			}
		}
		logger.info("End insert report|" + list.size() + "|" + (System.currentTimeMillis() - startInsert));
	}

	private int daysBetween(long t1, long t2) {
		return (int) ((t2 - t1) / (1000 * 60 * 60 * 24));
	}

	/**
	 * Thuc hien lay ban tin theo mode auto hoac manual <br/>
	 *
	 * @author NghiaLD <nghiald@viettel.com>
	 * @created_at: 7/25/16 3:47 PM
	 * @return
	 * @throws ParseException
	 */
	public List<DailyRevenueReport> synthesisDailyRevenue() throws ParseException, Exception {
		Date reportDate;
		List<DailyRevenueReport> dailyReports;
		List<DailyRevenueReport> lst = new ArrayList<>();
		if (config.getMode() == Config.MANUAL_MODE) {
			Date startTime = sdf.parse(config.getReportDateStart());
			Date endTime = sdf.parse(config.getReportDateEnd());
			int days = daysBetween(startTime.getTime(), endTime.getTime());
			for (int i = 0; i <= days; i++) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(startTime);
				cal.add(Calendar.DATE, i);
				reportDate = cal.getTime();
				String strReportDate = sdf.format(reportDate);
				logger.info("Start scan with report_date: " + strReportDate);
				int n = dao.clearDailyRevenue(reportDate);
				if (n < 0) {
					throw new Exception("Clear daily revenue error");
				} else {
					logger.info("Clear daily revenue|reportDate=" + strReportDate + "|" + n);
				}
				dailyReports = dao.synthesisDailyRevenue(reportDate);
				for (DailyRevenueReport rp : dailyReports) {
					lst.add(rp);
				}
			}
			logger.info("size report: " + lst.size());
			return lst;
		} else {
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, -1);
			reportDate = cal.getTime();
			return dao.synthesisDailyRevenue(reportDate);
		}

	}

	public List<ReportContents> buidReportContents() throws ParseException, Exception {
		Date reportDate;
		if (config.getMode() == Config.AUTO_MODE) {
			logger.info("Start to build report contents");
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, -1);
			reportDate = cal.getTime();
			return dao.getReportContentByDate(reportDate);
		} else {
			logger.info("AUTO_MODE is manual; NOT BUILD report content");
		}
		return null;
	}

	/**
	 * Insert cac ban ghi da tong hop vao SMS_MT va EMAIL_SEND_QUEUE
	 *
	 * @author NghiaLD <nghiald@viettel.com>
	 * @param list
	 * @created_at: 7/25/16 2:12 PM
	 */
	public void insertReportContents(List<ReportContents> list) {
		long startInsert = System.currentTimeMillis();
		logger.info("Start insert report contents|" + list.size());

		String configPhone = config.getSysConfigByKey("REPORT_PHONE_NUMBER");
		String[] phoneList = configPhone.split(",");
		String shortCode = config.getSysConfigByKey("REPORT_SMS_SHORT_CODE");
		String configEmail = config.getSysConfigByKey("REPORT_EMAIL_ADDRESS");
		String configEmailCc = config.getSysConfigByKey("REPORT_EMAIL_ADDRESS_CC");

		String smsContent = config.getSysConfigByKey("REPORT_SMS_CONTENT");
		String emailContent = config.getSysConfigByKey("REPORT_EMAIL_CONTENT");
		String emailSubject = config.getSysConfigByKey("REPORT_EMAIL_SUBJECT");
		String smsContentParamOriginal = getOnlyParam(smsContent);
		String emailContentParamOriginal = getOnlyParam(emailContent);
		String smsContentParam, emailContentParam;

		StringBuilder smsContentCombie = new StringBuilder();
		StringBuilder emailContentCombie = new StringBuilder();
		for (ReportContents rp : list) {
			logger.info(rp.toString());
			emailSubject = emailSubject.replaceAll("%report_date%", rp.getReportDate());
			smsContent = smsContent.replaceAll("%report_date%", rp.getReportDate());
			emailContent = emailContent.replaceAll("%report_date%", rp.getReportDate());
			smsContentParam = smsContentParamOriginal
				.replaceAll("%campaign_name%", rp.getCampaignName())
				.replaceAll("%partner_name%", rp.getPartnerName())
				.replaceAll("%current_data%", rp.getCurrentIssue())
				.replaceAll("%max_data%", rp.getMaxIssue())
				.replaceAll("%percent%", rp.getPercent());
			smsContentCombie.append(smsContentParam);
			emailContentParam = emailContentParamOriginal
				.replaceAll("%campaign_name%", rp.getCampaignName())
				.replaceAll("%partner_name%", rp.getPartnerName())
				.replaceAll("%current_data%", rp.getCurrentIssue())
				.replaceAll("%max_data%", rp.getMaxIssue())
				.replaceAll("%percent%", rp.getPercent());

			emailContentCombie.append(emailContentParam);
		}

		smsContent = smsContent.replaceAll(regexString, smsContentCombie.toString());
		emailContent = emailContent.replaceAll(regexString, emailContentCombie.toString());
		
		smsContent= StringUtils.unAccent(smsContent);
		logger.info("smsContent: " + smsContent);
		logger.info("emailContent: " + emailContent);
		//insert MT
		ArrayList<SmsMt> lstSmsMt = new ArrayList<SmsMt>();
		for (int i = 0; i < phoneList.length; i++) {
			SmsMt smsMt = new SmsMt();
			smsMt.setMsisdn(phoneList[i]);
			smsMt.setMessage(smsContent);
			smsMt.setChannel(shortCode);
			lstSmsMt.add(smsMt);
		}
		long start = System.currentTimeMillis();

		ArrayList<SmsMt> lstSms = new ArrayList<>();
		for (SmsMt mt : lstSmsMt) {
			lstSms.add(mt);
			if (lstSms.size() > batchSize) {
				try {
					dao.insertBatchSmsMt(lstSmsMt);
					logger.info("Timeprocess|CoreBusiness|InsertBatch|SMS_MT|" + lstSmsMt.size() + "|" + (System.currentTimeMillis() - start));
					lstSmsMt.clear();
				} catch (Exception ex) {
					logger.error("Insert batcc SMS_MT error", ex);
				}
			}
		}
		//insert nhung ban ghi ngoai block batch
		if (lstSms.size() > 0) {
			try {
				dao.insertBatchSmsMt(lstSmsMt);
				logger.info("Timeprocess|CoreBusiness|InsertBatch|SMS_MT|" + lstSmsMt.size() + "|" + (System.currentTimeMillis() - start));
				lstSmsMt.clear();
			} catch (Exception ex) {
				logger.error("Insert batcc SMS_MT error", ex);
			}
		}

		try {
			EmailSendQueue email = new EmailSendQueue();
			email.setContent(emailContent);
			email.setSubject(emailSubject);
			email.setSendTo(configEmail);
			email.setSendCc(configEmailCc);
			dao.insertEmailSendQueue(email);
			logger.info("Timeprocess|CoreBusiness|InsertBatch|EMAIL_SEND_QUEUE|" + (System.currentTimeMillis() - start));
		} catch (Exception ex) {
			logger.error("Insert batcc EMAIL_SEND_QUEUE error", ex);
		}

		logger.info("End insert report content|" + list.size() + "|" + (System.currentTimeMillis() - startInsert));
	}

	private String getOnlyParam(String input) {
		Pattern pattern = Pattern.compile(regexString);
		Matcher matcher = pattern.matcher(input);
		if (matcher.find()) {
			input = matcher.group(1);
		}
		return input;
	}

}
