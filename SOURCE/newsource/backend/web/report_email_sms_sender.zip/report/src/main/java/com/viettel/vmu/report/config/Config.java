/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.vmu.report.config;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import org.apache.log4j.Logger;

/**
 *
 * @author NGHIALD
 */
public class Config {

	private static final Logger logger = Logger.getLogger(Config.class);
	//
	public static final int AUTO_MODE = 0;
	public static final int MANUAL_MODE = 1;
	//
	private static final String TRIGGER_SYNTHESIS_DAILY = "report.daily.synthesis.trigger";
	private static final String SYNTHESIS_MANUAL_MODE = "report.synthesis.manual.mode";
	private static final String SYNTHESIS_DATE_REPORT_START = "report.synthesis.date.start";
	private static final String SYNTHESIS_DATE_REPORT_END = "report.synthesis.date.end";
	public static final String DB_CONFIG_PATH = "report.daily.db.config.path";
	public static final String DB_BATCH_SIZE = "report.daily.db.batch.size";

	private HashMap<String, String> sysConfig;

	private final Properties pro;

	public Config(String cfgPath) throws FileNotFoundException, IOException {
		pro = new Properties();
		pro.load(new FileInputStream(cfgPath));
	}

	/**
	 * cau hinh crontab bat dau tong hop bao cao <br/>
	 * dinh dang crontab theo quartz:
	 * <a href='http://www.quartz-scheduler.org/documentation/quartz-2.x/tutorials/crontrigger.html'>
	 * http://www.quartz-scheduler.org/documentation/quartz-2.x/tutorials/crontrigger.html</a>
	 *
	 * @author NghiaLD <nghiald@viettel.com>
	 * @return
	 * @created_at: 7/25/16 9:26 AM
	 */
	public String getTriggerSynthesisDaily() {
		return pro.getProperty(TRIGGER_SYNTHESIS_DAILY, "0 0 1 * * ?");
	}

	public int getMode() {
		return Integer.parseInt(pro.getProperty(SYNTHESIS_MANUAL_MODE, "0"));
	}

	public String getReportDateStart() {
		return pro.getProperty(SYNTHESIS_DATE_REPORT_START);
	}

	public String getReportDateEnd() {
		return pro.getProperty(SYNTHESIS_DATE_REPORT_END);
	}
	
	public String getDbCfgPath() {
		return pro.getProperty(DB_CONFIG_PATH, "../etc/dbCfg.cfg");
	}

	public int getBatchSize() {
		return Integer.parseInt(pro.getProperty(DB_BATCH_SIZE, "100"));
	}

	public void setSysConfig(HashMap sysConfig) {
		this.sysConfig = sysConfig;
	}

	public synchronized String getSysConfigByKey(String key) {
		String result = "";
		if (sysConfig.containsKey(key)) {
			for (Map.Entry<String, String> entry : sysConfig.entrySet()) {
				if (key.equals(entry.getKey())) {
					result = entry.getValue();
					break;
				}
			}
		}
		if("".equals(result)){
			logger.info("Key not found in sys_config: "+key);
		}
		return result;
	}

}
