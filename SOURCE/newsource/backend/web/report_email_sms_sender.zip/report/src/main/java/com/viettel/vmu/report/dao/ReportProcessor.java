/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.vmu.report.dao;

import com.viettel.cluster.agent.integration.DbProcessor;
import com.viettel.cluster.agent.integration.Record;
import com.viettel.pool.connection.OracleConnection;
import com.viettel.pool.connection.TimestenConnection;
import com.viettel.vmu.report.model.DailyRevenueReport;
import com.viettel.vmu.report.model.EmailSendQueue;
import com.viettel.vmu.report.model.ReportContents;
import com.viettel.vmu.report.model.SmsMt;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import org.apache.log4j.Logger;

/**
 *
 * @author THANHNV75
 */
public class ReportProcessor implements DbProcessor {

	private static final Logger logger = Logger.getLogger(ReportProcessor.class);
	private String sqlDailyRevenue = "select \n"
		+ " partner_id,\n"
		+ " campaign_id,\n"
		+ " address,\n"
		+ " port,\n"
		+ " sum(data) as total_data, \n"
		+ " sum(number_access) as total_number_access \n"
		+ " from log_data_query \n"
		+ " where end_time between ? and ? \n"
		+ " group by partner_id, campaign_id, address,port";
	private String sqlInsertDailyRevenue = "insert into report_campaign_daily("
		+ "report_date,partner_id,campaign_id,address,port,data,number_access)"
		+ " values (?,?,?,?,?,?,?)";
	private String sqlDeleteDailyRevenue = "delete from report_campaign_daily\n"
		+ "  where report_date = ? ";
	private String sqlReportContent = "SELECT b.campaign_type AS campaign_type, "
		+ "COALESCE(b.name,'UnKnown') AS campaign_name, "
		+ "b.max_data as max_data, "
		+ "b.max_number_access as max_number_access, "
		+ "COALESCE(c.name,'UnKnown') AS partner_name,"
		+ "SUM(a.data) AS total_data, "
		+ "SUM(a.number_access) AS total_number_access "
		+ "FROM log_data_query a "
		+ "LEFT JOIN campaign b ON a.campaign_id= b.id \n"
		+ "LEFT JOIN partner c ON a.partner_id = c.id \n"
		+ "where a.end_time between ? and ? \n"
		+ "GROUP BY b.name, c.name, b.campaign_type,b.max_data,b.max_number_access";

	private String sqlInsertSmsMt = "insert into sms_mt("
		+ "msisdn,message,receive_time,app_id,retry_sent_count,channel,is_spam)"
		+ " values (?,?,?,?,?,?,?)";

	private String sqlInsertEmailSendQueue = "insert into email_send_queue("
		+ "subject,content,send_to,send_cc,receive_time,app_id,retry_sent_count,is_spam)"
		+ " values (?,?,?,?,?,?,?,?)";

	private static ReportProcessor instance;
	private TimestenConnection conn;
	private int dbRetry;
	private static final Logger log = Logger.getLogger(ReportProcessor.class);

	public static ReportProcessor getInstance() {
		synchronized (ReportProcessor.class) {
			if (instance == null) {
				logger.error("Datasource must be initialized!");
			}
		}
		return instance;
	}

	private ReportProcessor(String configPath, int dbRetry) {
		try {
			conn = (TimestenConnection) OracleConnection.getInstance(configPath);
			this.dbRetry = dbRetry;
		} catch (Exception e) {
			logger.error("Initialize database connection failed.", e);
		}
	}

	public static void init(String configPath, Integer dbRetry) {
		synchronized (ReportProcessor.class) {
			if (instance != null) {
				return;
			}
			instance = new ReportProcessor(configPath, dbRetry);
		}
	}

	public void setSqlDailyRevenue(String sqlDailyRevenue) {
		this.sqlDailyRevenue = sqlDailyRevenue;
	}

	public void setSqlInsertDailyRevenue(String sqlInsertDailyRevenue) {
		this.sqlInsertDailyRevenue = sqlInsertDailyRevenue;
	}

	@Override
	public void setStatement(String string) {
		logger.info("set statement: " + string);
	}

	@Override
	public String getStatement() {
		logger.info("get Statement");
		return null;
	}

	@Override
	public void updateStatement(String string) {
		logger.info("update statement: " + string);
	}

	@Override
	public List<Record> getRecords() {
		logger.info("getRecords");
		return null;
	}

	@Override
	public int updateProcessedRecord(List<Long> list) {
		logger.info("updateProcessedRecord:" + list);
		return 0;
	}

	@Override
	public void processTimeoutRecord(List<Long> list) {
		logger.info("processTimeoutRecord:" + list);
	}

	@Override
	public Record parse(ResultSet rs) {
		DailyRevenueReport rp = null;
		try {
			rp = new DailyRevenueReport();
			rp.setReportDate(rs.getDate("DATE"));
			rp.setAddress(rs.getString("address"));
			rp.setCampaignId(rs.getLong("campaign_id"));
			rp.setPartnerId(rs.getLong("partner_id"));
			rp.setPort(rs.getInt("port"));
			rp.setTotalData(rs.getString("total_data"));
			rp.setTotalNumberAccess(rs.getString("total_number_access"));
			return rp;
		} catch (SQLException ex) {
			logger.error("Record parse error", ex);
		}
		return (Record) rp;
	}

	@Override
	public int checkDatabase() {
		return 0;
	}

	public void insertBatchDailyRevenueReport(ArrayList<DailyRevenueReport> reports) throws Exception {
		Connection con = null;
		PreparedStatement pre = null;
		ResultSet set = null;
		long start = System.currentTimeMillis();
		try {
			con = conn.getConnection();
			pre = conn.getPrepared(con, sqlInsertDailyRevenue);
			con.setAutoCommit(false);
			for (DailyRevenueReport rp : reports) {
				pre.setDate(1, new java.sql.Date(rp.getReportDate().getTime()));
				pre.setLong(2, rp.getPartnerId());
				pre.setLong(3, rp.getCampaignId());
				pre.setString(4, rp.getAddress());
				pre.setInt(5, rp.getPort());
				pre.setString(6, rp.getTotalData());
				pre.setString(7, rp.getTotalNumberAccess());
				pre.addBatch();
			}
			pre.executeBatch();
			con.commit();
			log.info("TimeProcess|insertBatchDailyRevenueReport|" + reports.size() + "|" + (System.currentTimeMillis() - start));
		} catch (Exception e) {
//			if (con != null) {
//				con.rollback();
//			}
			log.error("insertBatchDailyRevenueReport - ERROR", e);
			throw e;
		} finally {
			conn.close(set, sqlInsertDailyRevenue);
			conn.close(pre, sqlInsertDailyRevenue);
			conn.close(con, sqlInsertDailyRevenue);
			log.info("Time to execute function insertBatchDailyRevenueReport is :" + (System.currentTimeMillis() - start));
		}
	}

	public int clearDailyRevenue(Date reportDate) throws SQLException, Exception {
		int row = -1;
		Connection con = null;
		PreparedStatement pre = null;
		ResultSet set = null;
		long start = System.currentTimeMillis();
		try {
			con = conn.getConnection();
			pre = conn.getPrepared(con, sqlDeleteDailyRevenue);
			pre.setDate(1, new java.sql.Date(reportDate.getTime()));
			con.setAutoCommit(false);
			row = pre.executeUpdate();
			con.commit();
			log.info("TimeProcess|ClearDailyRevenue|ReportDate=" + reportDate + "|" + (System.currentTimeMillis() - start));
		} catch (Exception e) {
//			if (con != null) {
//				con.rollback();
//			}
			log.error("clearDailyRevenue - ERROR", e);
			throw e;
		} finally {
			conn.close(set, sqlDeleteDailyRevenue);
			conn.close(pre, sqlDeleteDailyRevenue);
			conn.close(con, sqlDeleteDailyRevenue);
			log.info("Time to execute function clearDailyRevenue is :" + (System.currentTimeMillis() - start));
		}
		return row;
	}

	public HashMap<String, String> getSysConfig() {
		Connection con = null;
		PreparedStatement pre = null;
		ResultSet rs = null;
		long start = System.currentTimeMillis();
		HashMap sysConfig = null;
		String sql = "select config_key, config_value from sys_config";
		try {
			con = conn.getConnection();
			pre = conn.getPrepared(con, sql);
			rs = pre.executeQuery();
			sysConfig = new HashMap<String, String>();
			while (rs.next()) {
				sysConfig.put(rs.getString("config_key"), rs.getString("config_value"));
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			conn.close(rs, sql);
			conn.close(pre, sql);
			conn.close(con, sql);
			log.info("Time to execute function getSysConfig is :" + (System.currentTimeMillis() - start));
		}
		logger.info("load Sys_config with total record: " + (sysConfig != null ? sysConfig.size() : 0));
		return sysConfig;
	}
	
	/**
	 * Tong hop bao cao vao ngay cu the theo reportDate
	 *
	 * @author NghiaLD <nghiald@viettel.com>
	 * @param reportDate
	 * @return
	 * @created_at: 7/25/16 3:13 PM
	 */
	public List<DailyRevenueReport> synthesisDailyRevenue(Date reportDate) {
		Connection con = null;
		PreparedStatement pre = null;
		ResultSet rs = null;
		ArrayList<DailyRevenueReport> dailyReports = null;
		long begin = System.currentTimeMillis();
		try {
			con = conn.getConnection();
			//Khoi tao thoi gian tong hop
			Calendar cal = Calendar.getInstance();
			cal.setTime(reportDate);
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 1);
			cal.set(Calendar.MILLISECOND, 0);
			//
			Date startDate = cal.getTime();
			cal.set(Calendar.SECOND, 0);
			cal.add(Calendar.DATE, 1);
			Date endDate = cal.getTime();

			pre = conn.getPrepared(con, sqlDailyRevenue);
			pre.setTimestamp(1, new java.sql.Timestamp(startDate.getTime()));
			pre.setTimestamp(2, new java.sql.Timestamp(endDate.getTime()));
			rs = pre.executeQuery();
			dailyReports = new ArrayList<>();
			while (rs.next()) {
				DailyRevenueReport rp = new DailyRevenueReport();
				rp.setReportDate(reportDate);
				rp.setAddress(rs.getString("address"));
				rp.setCampaignId(rs.getLong("campaign_id"));
				rp.setPartnerId(rs.getLong("partner_id"));
				rp.setPort(rs.getInt("port"));
				rp.setTotalData(rs.getString("total_data"));
				rp.setTotalNumberAccess(rs.getString("total_number_access"));
				dailyReports.add(rp);
			}
			logger.info("Timeprocess|SynthesisDailyRevenue|" + dailyReports.size() + "|" + (System.currentTimeMillis() - begin));
		} catch (Exception e) {
			log.error("synthesisDailyRevenue - ERROR", e);
		} finally {
			conn.close(rs, sqlDailyRevenue);
			conn.close(pre, sqlDailyRevenue);
			conn.close(con, sqlDailyRevenue);
			log.info("Time to execute function synthesisDailyRevenue is :" + (System.currentTimeMillis() - begin));
		}
		return dailyReports;
	}

	public List<ReportContents> getReportContentByDate(Date reportDate) {
		Connection con = null;
		PreparedStatement pre = null;
		ResultSet rs = null;
		ArrayList<ReportContents> reportContents = null;
		long begin = System.currentTimeMillis();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		try {
			con = conn.getConnection();
			//Khoi tao thoi gian tong hop
			Calendar cal = Calendar.getInstance();
			cal.setTime(reportDate);
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			
			cal.set(Calendar.SECOND, 1);
			cal.set(Calendar.MILLISECOND, 0);
			//
			Date startDate = cal.getTime();
			cal.set(Calendar.SECOND, 0);
			cal.add(Calendar.DATE, 1);
			
			Date endDate = cal.getTime();

			pre = conn.getPrepared(con, sqlReportContent);
			pre.setTimestamp(1, new java.sql.Timestamp(startDate.getTime()));
			pre.setTimestamp(2, new java.sql.Timestamp(endDate.getTime()));
			rs = pre.executeQuery();
			reportContents = new ArrayList<>();
			String strReportDate=sdf.format(reportDate);
			while (rs.next()) {
				ReportContents rp = new ReportContents();
				int campaignType = rs.getInt("campaign_type");
				double maxIssue = 0, currentIssue = 0;
				
				if (campaignType == 0) {
					//tinh theo data
					currentIssue = rs.getDouble("total_data");
					maxIssue = rs.getInt("max_data");
				} else if (campaignType == 1) {
					//tinh theo luong truy cap
					currentIssue = rs.getDouble("total_number_access");
					maxIssue = rs.getInt("max_number_access");
				}
				double percent;
				if(maxIssue>0){
					percent = (currentIssue / maxIssue)*100;
				}else{
					percent=0;
				}
				
				rp.setReportDate(strReportDate);
				rp.setCampaignName(rs.getString("campaign_name"));
				rp.setCurrentIssue(String.valueOf(Math.round(currentIssue)));
				rp.setMaxIssue(String.valueOf(Math.round(maxIssue)));
				rp.setPartnerName(rs.getString("partner_name"));
				rp.setPercent(String.valueOf(percent)+"%");
				reportContents.add(rp);
			}
			logger.info("Timeprocess|getReportContentByDate|" + reportContents.size() + "|" + (System.currentTimeMillis() - begin));
		} catch (Exception e) {
			log.error("getReportContentByDate - ERROR", e);
		} finally {
			conn.close(rs, sqlReportContent);
			conn.close(pre, sqlReportContent);
			conn.close(con, sqlReportContent);
			log.info("Time to execute function getReportContentByDate is :" + (System.currentTimeMillis() - begin));
		}
		return reportContents;
	}

	public void insertBatchSmsMt(ArrayList<SmsMt> lstSmsMt) throws Exception {
		Connection con = null;
		PreparedStatement pre = null;
		ResultSet set = null;
		long start = System.currentTimeMillis();
		try {
			con = conn.getConnection();
			pre = conn.getPrepared(con, sqlInsertSmsMt);
			con.setAutoCommit(false);
			for (SmsMt mt : lstSmsMt) {
				pre.setString(1, mt.getMsisdn());
				pre.setString(2, mt.getMessage());
				pre.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
				pre.setString(4, "Report");
				pre.setInt(5, 0);
				pre.setString(6, mt.getChannel());
				pre.setInt(7, 1);
				pre.addBatch();
			}
			pre.executeBatch();
			con.commit();
			log.info("TimeProcess|insertBatchSmsMt|" + lstSmsMt.size() + "|" + (System.currentTimeMillis() - start));
		} catch (Exception e) {
//			if (con != null) {
//				con.rollback();
//			}
			log.error("insertBatchSmsMt - ERROR", e);
			throw e;
		} finally {
			conn.close(set, sqlInsertSmsMt);
			conn.close(pre, sqlInsertSmsMt);
			conn.close(con, sqlInsertSmsMt);
			log.info("Time to execute function insertBatchSmsMt is :" + (System.currentTimeMillis() - start));
		}
	}

	public void insertEmailSendQueue(EmailSendQueue email) throws Exception {
		Connection con = null;
		PreparedStatement pre = null;
		ResultSet set = null;
		long start = System.currentTimeMillis();
		try {
			con = conn.getConnection();
			pre = conn.getPrepared(con, sqlInsertEmailSendQueue);
			con.setAutoCommit(false);
			pre.setString(1, email.getSubject());
			pre.setString(2, email.getContent());
			pre.setString(3, email.getSendTo());
			pre.setString(4, email.getSendCc());
			pre.setTimestamp(5, new Timestamp(System.currentTimeMillis()));
			pre.setString(6, "Report");
			pre.setInt(7, 0);
			pre.setInt(8, 1);
			pre.addBatch();
			pre.executeBatch();
			con.commit();
			log.info("TimeProcess|insertBatchEmailSendQueue|" + (System.currentTimeMillis() - start));
		} catch (Exception e) {
//			if (con != null) {
//				con.rollback();
//			}
			log.error("insertBatchEmailSendQueue - ERROR", e);
			throw e;
		} finally {
			conn.close(set, sqlInsertEmailSendQueue);
			conn.close(pre, sqlInsertEmailSendQueue);
			conn.close(con, sqlInsertEmailSendQueue);
			log.info("Time to execute function insertBatchEmailSendQueue is :" + (System.currentTimeMillis() - start));
		}
	}
}
