/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.vmu.report.model;

/**
 *
 * @author thanhnv75
 */
public class ReportContents {
	
	private String reportDate;
	private String campaignName;
	private String partnerName;
	private String currentIssue;
	private String maxIssue;
	private String percent;

	public String getReportDate() {
		return reportDate;
	}

	public void setReportDate(String reportDate) {
		this.reportDate = reportDate;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public String getCurrentIssue() {
		return currentIssue;
	}

	public void setCurrentIssue(String currentIssue) {
		this.currentIssue = currentIssue;
	}

	public String getMaxIssue() {
		return maxIssue;
	}

	public void setMaxIssue(String maxIssue) {
		this.maxIssue = maxIssue;
	}

	public String getPercent() {
		return percent;
	}

	public void setPercent(String percent) {
		this.percent = percent;
	}

	@Override
	public String toString() {
		StringBuilder sb= new StringBuilder("@@@@@@@@@@@@=>ReportContents info: |");
		sb.append("|Date: ").append(reportDate)
			.append("|CampaignName: ").append(campaignName)
			.append("|PartnerName: ").append(partnerName)
			.append("|Current issue: ").append(currentIssue)
			.append("|Max issue: ").append(maxIssue)
			.append("|Percent: ").append(percent);
		return sb.toString();
	}
	
}
