/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.vmu.report.run;

import com.viettel.pool.exception.ConnectionPoolException;
import com.viettel.vmu.report.Report;
import java.io.IOException;
import java.text.ParseException;
import javax.naming.ConfigurationException;
import org.quartz.SchedulerException;

/**
 *
 * @author NGHIALD
 */
public class Start {

    public static void main(String[] args) throws SchedulerException, IOException, ConfigurationException, ConnectionPoolException, ParseException, Exception {
        Report.getInstance().start();
    }
}
