/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.vmu.report.run.thread;

import com.viettel.cluster.agent.Dispatcher;
import com.viettel.vmu.report.CoreBusiness;
import com.viettel.vmu.report.config.Config;
import com.viettel.vmu.report.model.DailyRevenueReport;
import com.viettel.vmu.report.model.ReportContents;
import java.text.ParseException;
import java.util.List;
import org.apache.log4j.Logger;

/**
 *
 * @author NGHIALD
 */
public class SynthesisDailyThread {

	private static final Logger logger = Logger.getLogger(SynthesisDailyThread.class);
	private int gossipTry = 100;
	private long waitGossip = 1000;
	private Dispatcher dispatcher = null;
	private CoreBusiness codeBusiness;
	private String processId;

	private Config config;

	public void setGossipTry(int gossipTry) {
		this.gossipTry = gossipTry;
	}

	public void setWaitGossip(long waitGossip) {
		this.waitGossip = waitGossip;
	}

	public void setDispatcher(Dispatcher dispatcher) {
		this.dispatcher = dispatcher;
	}

	public void setCodeBusiness(CoreBusiness codeBusiness) {
		this.codeBusiness = codeBusiness;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}

	public void setConfig(Config config) {
		this.config = config;
	}

	public void start() throws ParseException, Exception {
		logger.info("Start thread SynthesisDailyThread");
		int dCount = 0;
		while (dispatcher.getState() != Dispatcher.DispatcherState.RUNNING) {
			logger.info("Waiting for gossip nodes|" + dispatcher.getMembers() + "|" + dispatcher.getOrder() + "|" + dispatcher.getState());
			if (dCount++ > gossipTry) {
				logger.error("Gossip can't run");
				break;
			}
			dispatcher = Dispatcher.getInstance(processId);
			try {
				logger.info("Waiting gossip node is running ... " + waitGossip + " ms");
				Thread.sleep(waitGossip);
			} catch (InterruptedException ex) {
				logger.error("SynthesisDailyThread|getGossipError|", ex);
			}
		}
		if (dispatcher.getOrder() == 0) {
			logger.info("Node is master, go to synthesis !!!");
			synthesisReport();
		} else {
			logger.info("Node is slave, go to sleep !!!");
		}
	}

	public void synthesisReport() throws Exception {
		long start = System.currentTimeMillis();
		logger.info("Start synthesis daily report");
		List<DailyRevenueReport> list = codeBusiness.synthesisDailyRevenue();
		if (list != null && !list.isEmpty()) {
			codeBusiness.insertReport(list);
			logger.info("End Synthesis daily revenue report|" + (System.currentTimeMillis() - start));
			logger.info("Timeprocess|SynthesisDailyReport|synthesisReport|" + list.size() + "|" + (System.currentTimeMillis() - start));
		} else {
			logger.error("No data to excuse report daily");
		}
		//insert content to report
		
		List<ReportContents> lstRC = codeBusiness.buidReportContents();
		if (lstRC != null && !lstRC.isEmpty()) {
			codeBusiness.insertReportContents(lstRC);
			logger.info("End buidReportContents|" + (System.currentTimeMillis() - start));
			logger.info("Timeprocess|buidReportContents|" + lstRC.size() + "|" + (System.currentTimeMillis() - start));
		}
	}

}
