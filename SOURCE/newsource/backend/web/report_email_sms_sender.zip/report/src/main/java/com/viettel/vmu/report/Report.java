/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.vmu.report;

import com.viettel.cluster.agent.Dispatcher;
import com.viettel.cluster.agent.utils.ConfigLoader;
import com.viettel.pool.exception.ConnectionPoolException;
import com.viettel.vmu.report.config.Config;
import com.viettel.vmu.report.dao.ReportProcessor;
import com.viettel.vmu.report.run.thread.SynthesisDailyJob;
import com.viettel.vmu.report.run.thread.SynthesisDailyThread;
import java.io.IOException;
import java.text.ParseException;
import javax.naming.ConfigurationException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import static org.quartz.CronScheduleBuilder.cronSchedule;
import static org.quartz.JobBuilder.newJob;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.Trigger;
import static org.quartz.TriggerBuilder.newTrigger;

/**
 *
 * @author NGHIALD
 */
public class Report {

    private static final Logger logger = Logger.getLogger(Report.class);
    private static Report intstance;
    private Dispatcher dispatcher = null;
    private final Scheduler scheduler;
    private static final String CONFIG_PATH = "../etc/app.cfg";
    private final Config config;
    private SynthesisDailyThread systhesisDaily;
    private CoreBusiness core;
    private ReportProcessor dao;
    private String processId = "ID_REPORT";

    public Report() throws SchedulerException, IOException, ConfigurationException, ConnectionPoolException, ParseException {
        PropertyConfigurator.configure("../etc/log4j.cfg");
        config = new Config(CONFIG_PATH);
        // gossip
        ConfigLoader.createInstance("../etc/agent.cfg");
		
//        dao = new ReportProcessor(config.getDbCfgPath(), config.getViettelSecurity());
		ReportProcessor.init(config.getDbCfgPath(), 3);
		dao =ReportProcessor.getInstance(); 
        if (Config.AUTO_MODE == config.getMode()) {
            while (true) {
                logger.info("Waiting for gossip nodes.........................");
                if (null == dispatcher) {
                    dispatcher = Dispatcher.createInstance(dao, processId, logger);
                }
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException ie) {
                    logger.error(ie);
                }
                if (null != dispatcher
                        && dispatcher.getState() == Dispatcher.DispatcherState.RUNNING) {
                    logger.info("Gossip running with " + dispatcher.getMembers() + " nodes");
                    break;
                }
            }
        }
        logger.info("Intialization CoreBusiness");
        core = new CoreBusiness();
        core.setDao(dao);
        core.setConfig(config);
        core.setBatchSize(config.getBatchSize());
		core.setSysConfigCore();
        logger.info("Initalization synthesisDaily");
        systhesisDaily = new SynthesisDailyThread();
        systhesisDaily.setDispatcher(dispatcher);
        systhesisDaily.setCodeBusiness(core);
        systhesisDaily.setProcessId(processId);
		systhesisDaily.setConfig(config);
        logger.info("Initialization corontab");
        SchedulerFactory schedFact = new org.quartz.impl.StdSchedulerFactory();
        scheduler = schedFact.getScheduler();
        JobDetail crontab = newJob(SynthesisDailyJob.class)
                .withIdentity("Report", "SynthesisDaily")
                .build();
        crontab.getJobDataMap().put("systhesisDaily", systhesisDaily);
        // Trigger the job to run now, and then every 40 seconds
        Trigger trigger = newTrigger()
                .startNow()
                .withSchedule(cronSchedule(config.getTriggerSynthesisDaily()))
                .build();

        // Tell quartz to schedule the job using our trigger
        scheduler.scheduleJob(crontab, trigger);

    }

    public static Report getInstance() throws SchedulerException, IOException, ConfigurationException, ConnectionPoolException, ParseException {
        synchronized (Report.class) {
            if (intstance == null) {
                intstance = new Report();
            }
        }
        return intstance;
    }

    public void start() throws SchedulerException, ParseException, Exception {
        if (Config.AUTO_MODE == config.getMode()) {
            logger.info("START REPORT WITH AUTO MODE");
            scheduler.start();
            logger.info("START AUTO DAILY REPORT");
        } else {
            logger.info("START REPORT WITH MANUAL MODE");
            logger.info("REPORT START DATE: " + config.getReportDateStart());
			logger.info("REPORT END DATE: " + config.getReportDateEnd());
            systhesisDaily.synthesisReport();
            logger.info("STOP MANUAL DAILY REPORT");
            System.exit(0);
        }
    }

    public void stop() throws SchedulerException {
        if (scheduler.isStarted()) {
            scheduler.shutdown();
        }
        logger.info("STOP DAILY REPORT.");
    }
}
