/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.vmu.report.model;

import com.viettel.cluster.agent.integration.Record;
import java.util.Date;

/**
 * Bao cao doanh thu
 *
 * @author THANHNV75
 */
public class DailyRevenueReport implements Record {

    private Date reportDate;
    private long partnerId;
	private long campaignId;
    private int port;
    private String address;
    private String totalData;
    private String totalNumberAccess;

    public Date getReportDate() {
        return reportDate;
    }

    public void setReportDate(Date reportDate) {
        this.reportDate = reportDate;
    }

	public long getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(long partnerId) {
		this.partnerId = partnerId;
	}

	public long getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(long campaignId) {
		this.campaignId = campaignId;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTotalData() {
		return totalData;
	}

	public void setTotalData(String totalData) {
		this.totalData = totalData;
	}

	public String getTotalNumberAccess() {
		return totalNumberAccess;
	}

	public void setTotalNumberAccess(String totalNumberAccess) {
		this.totalNumberAccess = totalNumberAccess;
	}

    @Override
    public long getID() {
        return hashCode();
    }

}
