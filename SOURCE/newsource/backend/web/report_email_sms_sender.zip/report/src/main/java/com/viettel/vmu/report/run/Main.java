/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.vmu.report.run;

import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author NGHIALD
 */
public class Main {

    public static void main(String[] args) {
//        Calendar cal = Calendar.getInstance();
//        cal.setTime(new Date());
//        cal.set(Calendar.HOUR_OF_DAY, 0);
//        cal.set(Calendar.MINUTE, 0);
//        cal.set(Calendar.SECOND, 0);
//        cal.set(Calendar.MILLISECOND, 0);
//        //
//        Date startDate = cal.getTime();
//        cal.add(Calendar.DATE, 1);
//        Date endDate = cal.getTime();
//        System.out.println("Start Date: " + startDate);
//        System.out.println("Start Date: " + endDate);
		
		float a=2001;
		float b= 10000;
		float c= (a/b) * 100;
		System.out.println("SS: "+c);
		
		
    }
}
