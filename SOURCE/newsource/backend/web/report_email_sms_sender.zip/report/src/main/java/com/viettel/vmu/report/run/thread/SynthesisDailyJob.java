/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.vmu.report.run.thread;

import java.text.ParseException;
import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 *
 * @author NGHIALD
 */
public class SynthesisDailyJob implements Job {
    
    private static final Logger logger = Logger.getLogger(SynthesisDailyJob.class);
    
    @Override
    public void execute(JobExecutionContext jec) throws JobExecutionException {
        logger.info("Start Synthesis job");
        JobDataMap data = jec.getJobDetail().getJobDataMap();
        SynthesisDailyThread synthesis = (SynthesisDailyThread) data.get("systhesisDaily");
        try {
            synthesis.start();
        } catch (ParseException ex) {
            logger.error("Synthesis daily job", ex);
        } catch (Exception ex) {
            logger.error("Synthesis daily job", ex);
        }
    }
    
}
