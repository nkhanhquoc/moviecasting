
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author thanhnv75
 */
public class NewClass {

	public static void main(String[] args) {
//		String pattern="^((00|\\\\+)?84)?[2-9]{8,12}$";
//		
//		String input = "0988919297";
//		boolean result=input.matches(pattern);
//		System.out.println("IN: "+result);
		double currentIssue=576267779433.0;
		System.out.println("A:"+String.valueOf(Math.round(currentIssue)));
		
	}
	
}
