/*
 * Copyright 2011 Viettel Telecom. All rights reserved.
 * VIETTEL PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.viettel.Main;
//import java.util.Properties;
//import javax.mail.Message;
//import javax.mail.MessagingException;
//import javax.mail.PasswordAuthentication;
//import javax.mail.Session;
//import javax.mail.Transport;
//import javax.mail.internet.InternetAddress;
//import javax.mail.internet.MimeMessage;
import org.apache.log4j.PropertyConfigurator;

/**
 * Start
 * @author ThanhNV75
 * @version 1.0
 * @since 2017
 */
public class Start {

    public static void main(String[] args) throws Exception {
         PropertyConfigurator.configure("../etc/log.conf");
        // Khoi dong MAILERProcess
        ScanProcessManager.getInstance().start();
		 
//		 
//		 Properties props = new Properties();
//		props.put("mail.smtp.host", "smtp.viettel.com.vn");
//		props.put("mail.smtp.socketFactory.port", "465");
//		props.put("mail.smtp.socketFactory.class",
//				"javax.net.ssl.SSLSocketFactory");
//		props.put("mail.smtp.auth", "true");
//		props.put("mail.smtp.port", "465");
//
//		Session session = Session.getDefaultInstance(props,
//			new javax.mail.Authenticator() {
//				protected PasswordAuthentication getPasswordAuthentication() {
//					return new PasswordAuthentication("thanhnv75","Zenky@1995");
//				}
//			});
//
//		try {
//
//			Message message = new MimeMessage(session);
//			message.setFrom(new InternetAddress("thanhnv75@viettel.com.vn"));
//			message.setRecipients(Message.RecipientType.CC,
//					InternetAddress.parse("thanhnv75@viettel.com.vn"));
//			message.setRecipients(Message.RecipientType.TO,
//					InternetAddress.parse("bachpv1@viettel.com.vn"));
//			message.setSubject("Testing Subject");
//			message.setText("Dear Mail Crawler," +
//					"\n\n No spam to my email, please!");
//
//			Transport.send(message);
//
//			System.out.println("send Done");
//
//		} catch (MessagingException e) {
//			System.out.println("Error: "+e.getMessage());
//		}
//        
    }
}
