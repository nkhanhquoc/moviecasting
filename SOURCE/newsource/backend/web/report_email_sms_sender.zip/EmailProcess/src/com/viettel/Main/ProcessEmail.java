/*
 * Copyright 2011 Viettel Telecom. All rights reserved.
 * VIETTEL PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.viettel.Main;

import com.viettel.cluster.agent.Dispatcher;
import com.viettel.cluster.agent.integration.Record;
import com.viettel.cluster.agent.utils.ConfigHolder;
import com.viettel.cluster.agent.utils.ConfigLoader;
import com.viettel.mmserver.base.ProcessThreadMX;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.management.NotCompliantMBeanException;
import org.apache.log4j.Logger;
import com.viettel.email.database.DbAdapter;
import com.viettel.email.database.DbAgent;
import com.viettel.email.manager.AppManager;
import com.viettel.email.model.EmailSendQueue;
import com.viettel.email.process.SendMailSSL;

/**
 * Gui mail cho khach hang
 *
 * @author TungTT
 * @version 1.0
 * @since 01-03-2011
 */
public class ProcessEmail extends ProcessThreadMX {

//    private DbProcessorFW db;
//    private SmsSender sender;
	private String logLabel = ProcessEmail.class.getSimpleName() + ": ";
	// LBF
	private Dispatcher dispatcher;
	protected ConfigHolder holder;
	protected String agentId;
	protected Logger disLogger;
	private long timeStart;
	private StringBuilder br = new StringBuilder();
	public static final int STATUS_SUCCESS = 1;
	public static final int STATUS_FAIL = 0;
	
	private static final Logger log = Logger.getLogger(ProcessEmail.class);

	public ProcessEmail(String threadName, int moduleId) throws NotCompliantMBeanException, IOException, SQLException, Exception {
		super(threadName);
		// Dang ky Log
		registerAgent(AppManager.getAppId() + ":type=" + ProcessEmailManager.name + ",name=" + threadName);

//        db= new DbAdapter("../etc/dbconfig.cfg", 3);
		agentId = AppManager.getListAgent().get(moduleId);
		if (ConfigLoader.getInstance() == null) {
			ConfigLoader.createInstance("../etc/agent.cfg");
		}

		this.dispatcher = Dispatcher.getInstance(agentId);

		if (null == this.dispatcher) {
			this.dispatcher = Dispatcher.createInstance(new DbAgent(), agentId, log);
		}
		log.info("dispatcher.nember===========" + dispatcher.getMembers());

		holder = ConfigLoader.getInstance().getConfigHolder(agentId);
	}

	@Override
	public final void process() {
		buStartTime = new Date();
		List<Record> listRecords = null;
		List<EmailSendQueue> listEmail = null;
		List<EmailSendQueue> listSucc = new ArrayList<EmailSendQueue>();
		List<EmailSendQueue> listFail = new ArrayList<EmailSendQueue>();

		try {
			// Lay ban ghi trong EMAIL
			while (listRecords == null) {
				listRecords = dispatcher.getRecords(AppManager.getMaxRow());
			}

			timeStart = System.currentTimeMillis();
			if (listRecords.size() > 0) {
				// Process
				listEmail = new ArrayList<EmailSendQueue>();
				for (Record record : listRecords) {
					listEmail.add((EmailSendQueue) record);
				}
				listRecords.clear();

				br.setLength(0);
				br.append(logLabel);
				br.setLength(0);
				br.append("\r\n").
					append("|\tEMAIL_ID\t|").
					append("|\tSUBJECT\t|").
					append("|\t\tSEND_TO\t|\n");

				for (EmailSendQueue moRecord : listEmail) {
					br.append("|\t").
						append(moRecord.getMailId()).
						append("\t||\t").
						append(moRecord.getSubject()).
						append("\t||\t").
						append(moRecord.getSendTo()).
						append("\t||\t\n");
				}
				log.info(br);

				List<Long> listEmailIdInput = new ArrayList<Long>();
				for (EmailSendQueue moRecord : listEmail) {
					listEmailIdInput.add(moRecord.getMailId());
				}

				try {
					//1. process
					for (EmailSendQueue email : listEmail) {
						if (email.getRetryNum() < AppManager.getRetrySentCount()) {
							// Xu ly gui tin nhan
							String subject = email.getSubject();
							String content= email.getContent();
							String sendTo= email.getSendTo();
							String sendCc= email.getSendCc();
							if (subject == null || subject.trim().length() == 0 
								|| content == null || content.trim().length() == 0
								|| sendTo == null || sendTo.trim().length() == 0) {
								log.warn(logLabel + new Date() + "\nSubject or content or send_to is null: Subject=" + email.getSubject());
								email.setStatus(2);
								listSucc.add(email);
								continue;
							}

							//send email
							logger.info("Start to send mail");
							int result=SendMailSSL.getInstance().send(subject, content, sendTo, sendCc);
							if (result > 0) {
								log.info(logLabel + "Send Email: \"" + subject
									+ "\" to " + email.getSubject()+ " sucess");
								email.setStatus(0);
								listSucc.add(email);
							} else {
								// Update retry_count= retry_count+1 ; khi tat ca cac tin nhan gui that bai
								log.info(logLabel + "Send Email: \"" + subject
									+ "\" to " + email.getSubject() + " fail: " + email.getRetryNum());
								listFail.add(email);
							}
						} else {
							// Qua so lan retry => add de xoa
							email.setStatus(1);
							listSucc.add(email);
						}
					}

					//2. update retry when send error
					if (listFail.size() > 0) {
						if (DbAdapter.getInstance().updateRetry(listFail) == null) {
							br.setLength(0);
							br.append(logLabel).
								append("BREAK UPDATE RETRY_NUM table EMAIL_SEND_QUEUE ==> ERROR DATABASE ==> NOT PROCESS CONTINOUS\n").
								append(listEmail.toString());
							log.error(br);
							// update retry fail => return ko xu ly
							return;
						}
					}

					//ID EMAIL
					List<Long> listEmailId = new ArrayList<Long>();
					log.info("Size of list Succ: "+listSucc.size());
					for (EmailSendQueue email : listSucc) {
						listEmailId.add(email.getMailId());
					}
					//3. delete mt
					if (DbAdapter.getInstance().deleteEmail(listEmailId) == null) {
						br.setLength(0);
						br.append(logLabel).
							append("BREAK DELETE EMAIL ==> ERROR DATABASE ==> NOT PROCESS CONTINOUS\n").
							append(listEmail.toString());
						log.error(br);
						return;
					}

					// Remove khoi queue Dispatcher
					dispatcher.updateProcessedRecord(listEmailIdInput);

					//4. insert mt_his
					log.info("Size of list Succ to delete: "+listSucc.size());
					if (listSucc.size() > 0) {
						if (DbAdapter.getInstance().insertEmailSendHis(listSucc, holder.getNodeName(), holder.getClusterName()) == null) {
							br.setLength(0);
							br.append(logLabel).
								append("BREAK INSERT EMAIL_SEND_HIS ==> ERROR DATABASE\n").
								append(listEmail.toString());
							log.error(br);
						}
						try {
							Thread.sleep(300);
						} catch (Exception ex) {
							log.error("error to sleep: ", ex);
						}
					}

					br.setLength(0);
					br.append(logLabel).
						append("Total time to process ").
						append(listEmail.size()).
						append(" requests: ").
						append((System.currentTimeMillis() - timeStart)).
						append(" ms\n").
						append(listEmail.toString());
					log.info(br);
					listEmail.clear();
					listFail.clear();
					listSucc.clear();
				} catch (Exception ex) {
					buStartTime = null;
					br.setLength(0);
					br.append(logLabel).
						append(new Date()).
						append("\nERROR when send email:\n").
						append(listEmail);
					log.error(br, ex);
				}
			} else {
				// Khong con ban ghi nao trong MO => Sleep
				buStartTime = null;
				try {
					Thread.sleep(AppManager.getTimeSleep());
				} catch (InterruptedException ex) {
					log.error(logLabel + "ERROR Sleep Thread", ex);
				}
			}
		} catch (Exception ex) {
			buStartTime = null;
			br.setLength(0);
			br.append(logLabel).
				append(new Date()).
				append("\nERROR process:\n").
				append(listEmail);
			log.error(br, ex);
		}
	}
}
