/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.email.database;

import com.viettel.cluster.agent.integration.DbProcessor;
import com.viettel.cluster.agent.integration.Record;
import java.sql.ResultSet;
import java.util.List;
import org.apache.log4j.Logger;
import static com.viettel.email.database.DbAdapter.getTimeBreak;

/**
 * Database using with agent
 *
 * @author thanhnv75
 */
public class DbAgent implements DbProcessor {

    private static final Logger logger = Logger.getLogger(DbAgent.class);
    private String sqlEmail = "";
    private long timeSt;

    @Override
    public void setStatement(String sqlEmail) {
        this.sqlEmail = sqlEmail;
    }

    @Override
    public String getStatement() {
        return this.sqlEmail;
    }

    @Override
    public void updateStatement(String sqlEmail) {
        this.sqlEmail = sqlEmail;
    }

    @Override
    public int updateProcessedRecord(List<Long> list) {
        return 0;
    }

    @Override
    public Record parse(ResultSet rs) {
        return null;
    }

    @Override
    public List<Record> getRecords() {
        if (sqlEmail != null && sqlEmail.trim().length() > 0) {
            return DbAdapter.getInstance().getRecords(sqlEmail);
        } else {
            logger.info("SQL select email_send_queue is empty");
        }
        return null;
    }

    @Override
    public void processTimeoutRecord(List<Long> list) {
        timeSt = System.currentTimeMillis();
//        while (DbAdapter.getInstance().deleteEmail(list) == null) {
//            if (getTimeBreak() <= 0 || (System.currentTimeMillis() - timeSt) > getTimeBreak()) {
//                break;
//            }
//            try {
//                Thread.sleep(300);
//            } catch (Exception ex) {
//                logger.error("ERROR: "+ex.getMessage(), ex);
//            }
//        }
    }


    @Override
    public int checkDatabase() {
       
       return DbAdapter.getInstance().CheckDatabase();
    }
}
