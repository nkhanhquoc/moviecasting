/*
 * Copyright 2011 Viettel Telecom. All rights reserved.
 * VIETTEL PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.viettel.email.model;

/**
 * Thong tin tung tien trinh: ten, truy van MO, module
 * @author TungTT
 * @version 1.0
 * @since 01-03-2011
 */
public class ProcessInfo {

    private String name;
    private int moduleId;    

    public ProcessInfo(String name, int moduleId) {
        this.name = name;
        this.moduleId = moduleId;        
    }    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }  

    public int getModuleId() {
        return moduleId;
    }

    public void setModuleId(int moduleId) {
        this.moduleId = moduleId;
    }
}
