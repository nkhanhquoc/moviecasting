/*
 * Copyright 2011 Viettel Telecom. All rights reserved.
 * VIETTEL PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.viettel.email.manager;

import com.viettel.mmserver.base.ProcessManager;
import com.viettel.mmserver.base.ProcessThreadMX;
import com.viettel.utility.PropertiesUtils;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Properties;
import org.openide.util.Exceptions;
import com.viettel.Main.ProcessEmailManager;
import com.viettel.email.database.DbAdapter;
import com.viettel.email.model.Mailer;
import com.viettel.email.utils.ViettelException;
import utils.Config;

/**
 * Quan ly cac tien trinh
 *
 * @author TungTT
 * @version 1.0
 * @since 01-03-2011
 */
public abstract class AppManager extends ProcessThreadMX {

	private ProcessEmailManager mtManager;
	public int idThreadMo[];
	// Config
	private static String appId;
	private static int numThreads;
	private static int numModules;
	private static int maxRow;
	private static int timeSleep;
	// Config Database
	private int queryDbTimeout;
	private boolean enableQueryDbTimeout;
	private int breakQuery;

	private static long minTimeDb;
	private static long[] timesDbLevel;
	private static HashMap loggerDbMap;
	private static long[] timesSmswsLevel;
	private static HashMap loggerSmswsMap;
	private String dbConfig;
	private int dbRetry;
	//
	private static ArrayList<String> listAgent;
	private StringBuffer br = new StringBuffer();
	private boolean exception = false;

	private static int retrySentCount;
	//scan time 
	private static String sendTime;

	private static Mailer mail = new Mailer();

	public AppManager() throws Exception {
		super("AppManager");

		// Get appId
		String config = Config.getConfigDir() + File.separator + "app.conf";
		FileReader fileReader;
		fileReader = new FileReader(config);
		Properties pro = new Properties();
		pro.load(fileReader);

		// Ma ung dung
		String temp = "";
		int intTemp;
		try {
			temp = pro.getProperty("APP_ID").toUpperCase();
			logger.info("\tAPP_ID=" + temp);
			setAppId(temp);
		} catch (Exception ex) {
			br.setLength(0);
			br.append("APP_ID not found in app.conf\n");
			logger.warn(br, ex);
			exception = true;
		}
		// Number record in once process
		try {
			intTemp = Integer.parseInt(pro.getProperty("MAX_ROW"));
			if (intTemp <= 0) {
				logger.info("MAX_ROW invalid, set to 100");
				intTemp = 100;
			}
			logger.info("\tMAX_ROW=" + intTemp);
		} catch (Exception ex) {
			br.setLength(0);
			br.append("MAX_ROW not found in app.conf => Default value: 100");
			logger.warn(br, ex);
			intTemp = 100;
		}
		setMaxRow(intTemp);
		// Time sleep process MT
		try {
			intTemp = Integer.parseInt(pro.getProperty("TIME_SLEEP","1000"));
			if (intTemp <= 0) {
				logger.info("TIME_SLEEP invalid, set to 1000");
				intTemp = 1000;
			}
			logger.info("\tTIME_SLEEP=" + intTemp);
		} catch (Exception ex) {
			br.setLength(0);
			br.append("TIME_SLEEP not found in app.conf => Default value: 1000");
			logger.warn(br, ex);
			intTemp = 1000;
		}
		setTimeSleep(intTemp);
		// Number thread sender
		try {
			intTemp = Integer.parseInt(pro.getProperty("NUMBER_THREAD","1"));
			if (intTemp <= 0) {
				logger.info("NUMBER_THREAD invalid, set to 1");
				intTemp = 1;
			}
			logger.info("\tNUMBER_THREAD=" + intTemp);
			if (intTemp > 100) {
				intTemp = 100;
			}
		} catch (Exception ex) {
			br.setLength(0);
			br.append("NUMBER_THREAD not found in app.conf => Default value: 5");
			logger.warn(br, ex);
			intTemp = 5;
		}
		setNumThreads(intTemp);
		try {
			intTemp = Integer.parseInt(pro.getProperty("NUMBER_MODULE","1"));
			if (intTemp <= 0 || intTemp >100) {
				logger.info("NUMBER_MODULE invalid, set to 1");
				intTemp = 1;
			}
			logger.info("\tNUMBER_MODULE=" + intTemp);
		} catch (Exception ex) {
			br.setLength(0);
			br.append("NUMBER_MODULE not found in app.conf => Default value: 1");
			logger.warn(br, ex);
			intTemp = 1;
		}
		setNumModules(intTemp);

		try {
			intTemp = Integer.parseInt(pro.getProperty("RETRY_SENT_COUNT"));
			if (intTemp <= 0 ) {
				logger.info("RETRY_SENT_COUNT invalid, set to 3");
				intTemp = 3;
			}
			logger.info("\tRETRY_SENT_COUNT=" + intTemp);
		} catch (Exception ex) {
			br.setLength(0);
			br.append("RETRY_SENT_COUNT not found in app.conf => Default value: 3");
			logger.warn(br, ex);
			intTemp = 3;
		}
		setRetrySentCount(intTemp);

		//scan time
		try {
			temp = pro.getProperty("SEND_TIME", "07:00-12:00").trim();
			if (!temp.contains(":") || !temp.contains("-")) {
				logger.error("sendTime error| Wrong format");
			} else {
				String[] arrTime = temp.split("[|]");
				if (arrTime.length > 1) {
					for (String a : arrTime) {
						String[] arrTimeSub = a.split("[-]");
						for (String aSub : arrTimeSub) {
							String[] arrCom = aSub.split("[:]");
							if (Integer.parseInt(arrCom[0]) < 0 || Integer.parseInt(arrCom[0]) > 23) {
								logger.error("sendTime error| Wrong format; set default: 07:00-12:00");
								temp = "07:00-12:00";
								break;
							}
							if (Integer.parseInt(arrCom[1]) < 0 || Integer.parseInt(arrCom[1]) > 59) {
								logger.error("sendTime error| Wrong format; set default: 07:00-12:00");
								temp = "07:00-12:00";
								break;
							}
						}
					}
				} else {
					String[] arrTimeSub = temp.split("[-]");
					for (String aSub : arrTimeSub) {
						String[] arrCom = aSub.split("[:]");
						if (Integer.parseInt(arrCom[0]) < 0 || Integer.parseInt(arrCom[0]) > 23) {
							logger.error("sendTime error| Wrong format; set default: 07:00-12:00");
							temp = "07:00-12:00";
							break;
						}
						if (Integer.parseInt(arrCom[1]) < 0 || Integer.parseInt(arrCom[1]) > 59) {
							logger.error("sendTime error| Wrong format; set default: 07:00-12:00");
							temp = "07:00-12:00";
							break;
						}
					}
				}

			}
		} catch (Exception e) {
			logger.error("sendTime error: ", e);
		}
		logger.info("\tSEND_TIME=" + temp);
		setSendTime(temp);
		// Init Query timeout Database
		try {
			enableQueryDbTimeout = Boolean.parseBoolean(pro.getProperty("ENABLE_QUERY_DB_TIMEOUT", "false"));
			logger.info("\tenableQueryDbTimeout=" + enableQueryDbTimeout);
		} catch (Exception ex) {
			br.setLength(0);
			br.append("ENABLE_QUERY_DB_TIMEOUT not found in app.conf => "
				+ "Default value: ENABLE_QUERY_DB_TIMEOUT = FALSE\n");
			logger.warn(br, ex);
			enableQueryDbTimeout = false;
		}
		if (enableQueryDbTimeout) {
			try {
				queryDbTimeout
					= Integer.parseInt(pro.getProperty("QUERY_DB_TIMEOUT","60"));
				if (queryDbTimeout <= 0) {
					logger.info("QUERY_DB_TIMEOUT invalid, set to 60");
					queryDbTimeout = 60;
				}
				logger.info("\tQUERY_DB_TIMEOUT=" + queryDbTimeout);
			} catch (Exception ex) {
				br.setLength(0);
				br.append("QUERY_DB_TIMEOUT not found in app.conf; set default= 60\n");
				queryDbTimeout= 60;
				logger.warn(br, ex);
//				exception = true;
			}
			DbAdapter.setQueryTimeout(queryDbTimeout);
		}
		try {
			breakQuery
				= Integer.parseInt(pro.getProperty("BREAK_QUERY", "3000"));
			if (breakQuery <= 0 ) {
				logger.info("BREAK_QUERY invalid, set to 3000");
				breakQuery = 3000;
			}
			logger.info("\tBREAK_QUERY=" + breakQuery);
			DbAdapter.setTimeBreak(breakQuery);
		} catch (Exception ex) {
			br.setLength(0);
			br.append("BREAK_QUERY not found in app.conf; set default =3000\n");
			breakQuery= 3000;
			logger.warn(br, ex);
//			exception = true;
		}
		try {
			dbRetry = Integer.parseInt(pro.getProperty("dbRetry","1").trim());
			if (dbRetry < 0) {
				logger.error("dbRetry is invalid, set dbRetry =1");
				dbRetry = 1;
			}
		} catch (Exception e) {
			logger.error("dbRetry is invalid, set dbRetry =1", e);
			dbRetry = 1;
		}
		// load DB connection config
		try {
			dbConfig = pro.getProperty("database_config", "").trim();
			if (dbConfig.isEmpty()) {
				logger.error("database_config empty");
			}
			logger.info("\tdatabase_config: " + dbConfig);
			DbAdapter.init(dbConfig, dbRetry);
		} catch (Exception e) {
			logger.error("error to load DB connection: ", e);
			exception = true;
		}

		// load MAIL CONFIG
		try {
			temp = pro.getProperty("MAIL_SENDER", "").trim();
			if (temp.isEmpty()) {
				logger.error("MAIL_SENDER empty");
			}
			logger.info("\tMAIL_SENDER: " + temp);
		} catch (Exception e) {
			logger.error("error to load MAIL_SENDER: ", e);
			exception = true;
		}
		mail.setEmailSend(temp);

		try {
			temp = pro.getProperty("MAIL_USERNAME", "").trim();
			if (temp.isEmpty()) {
				logger.error("MAIL_USERNAME empty");
			}
			logger.info("\tMAIL_USERNAME: " + temp);
		} catch (Exception e) {
			logger.error("error to load MAIL_USERNAME: ", e);
			exception = true;
		}
		mail.setUserName(temp);

		try {
			temp = pro.getProperty("MAIL_PASSWORD", "").trim();
			if (temp.isEmpty()) {
				logger.error("MAIL_PASSWORD empty");
			}
			logger.info("\tMAIL_PASSWORD: *****");
		} catch (Exception e) {
			logger.error("error to load MAIL_PASSWORD: ", e);
			exception = true;
		}

		mail.setPassWord(temp);

		try {
			temp = pro.getProperty("MAIL_SOCKET_TIMEOUT", "30000").trim();
			if (temp.isEmpty()) {
				logger.error("MAIL_SOCKET_TIMEOUT empty");
			}
			logger.info("\tMAIL_SOCKET_TIMEOUT: " + temp);
		} catch (Exception e) {
			logger.error("error to load MAIL_SOCKET_TIMEOUT: ", e);
			exception = true;
		}

		mail.setSocketTimeout(temp);

		fileReader.close();

		// Load log warning
		loadLogLevelWarnning();

		// LBF
		PropertiesUtils prop = new PropertiesUtils();
		ArrayList<String> tempListAgent = new ArrayList<String>();
		prop.loadProperties("../etc/agent.cfg", false);
		String[] agPro = prop.getProperties();
		for (int i = 0; i < agPro.length; i++) {
			String str = agPro[i].trim().replaceAll("\r", "").replaceAll("\n", "");
			if (str.startsWith("#") || str.startsWith("//")) {
				continue;
			}
			if (str.startsWith("[") && str.endsWith("]")) {
				tempListAgent.add(str.substring(1, str.length() - 1));
			}
		}

		if (exception) {
			throw new ViettelException(br.toString());
		}
		setListAgent(tempListAgent);

		// Mt Sender
		mtManager = new ProcessEmailManager(appId);
	}

	/**
	 * Doc thong tin file loglevel.conf
	 */
	private void loadLogLevelWarnning() throws Exception {
		PropertiesUtils pros = new PropertiesUtils();
		pros.loadProperties("../etc/loglevel.conf", false);
		// Log Database
		HashMap temp;
		long[] tempLong;
		try {
			String[] dbTimes = pros.getProperty("DB_TIMES").split(",");
			String[] dbKey = pros.getProperty("DB_MESSAGE_KEY").split(",");
			temp = new HashMap();
			tempLong = new long[dbTimes.length];
			//set mintimeDB
			setMinTimeDb(Long.parseLong(dbTimes[0].trim()));
			for (int i = 0; i < dbTimes.length; i++) {
				tempLong[i] = Long.parseLong(dbTimes[i].trim());
				temp.put(i, dbKey[i].trim());
			}
		} catch (Exception ex) {
			logger.error("Loi lay thong tin DB_TIMES, DB_MESSAGE_KEY trong loglevel.conf: ", ex);
			throw ex;
		}
		setLoggerDbMap(temp);
		setTimesDbLevel(tempLong);
		// Log SMSGATEWAY
		HashMap tempLoggerSmswsMap;
		long[] tempTimesSmswsLevel;
		try {
			String[] ocsTimes = pros.getProperty("SMSWS_TIMES").split(",");
			String[] ocsKey = pros.getProperty("SMSWS_MESSAGE_KEY").split(",");
			tempLoggerSmswsMap = new HashMap();
			tempTimesSmswsLevel = new long[ocsTimes.length];
			for (int i = 0; i < ocsTimes.length; i++) {
				tempTimesSmswsLevel[i] = Long.parseLong(ocsTimes[i].trim());
				tempLoggerSmswsMap.put(i, ocsKey[i].trim());
			}
		} catch (Exception ex) {
			logger.error("Loi lay thong tin SMSWS_TIMES, SMSWS_MESSAGE_KEY trong loglevel.conf: ", ex);
			throw ex;
		}
		setTimesSmswsLevel(tempTimesSmswsLevel);
		setLoggerSmswsMap(tempLoggerSmswsMap);
	}

	/**
	 * Log cham database
	 *
	 * @param times
	 * @return
	 */
	public static String getTimeLevelDb(long times) {
		if (getLoggerDbMap() != null) {
			int key = Arrays.binarySearch(getTimesDbLevel(), times);
			if (key < 0) {
				key = -key - 2;
			}
			String label = (String) getLoggerDbMap().get(key);

			return (label == null) ? "-" : label;
		}
		return null;
	}

	/**
	 * Log cham ocs, hlr
	 *
	 * @param times
	 * @return
	 */
	public static String getTimeLevelSmsws(long times) {
		if (getLoggerSmswsMap() != null) {
			int key = Arrays.binarySearch(getTimesSmswsLevel(), times);
			if (key < 0) {
				key = -key - 2;
			}

			String label = (String) getLoggerSmswsMap().get(key);
			return (label == null) ? "-" : label;
		}
		return null;
	}
	//************************************************************************//

	@Override
	protected void process() {
		try {
			Thread.sleep(100000);
		} catch (InterruptedException ex) {
			Exceptions.printStackTrace(ex);
		}
	}

	@Override
	public void start() {
		ProcessManager.getInstance().getMmProcess(mtManager.getId()).start();
	}

	@Override
	public void stop() {
		ProcessManager.getInstance().getMmProcess(mtManager.getId()).stop();
	}

	public static String getAppId() {
		return appId;
	}

	public static void setAppId(String appId) {
		AppManager.appId = appId;
	}

	public static int getNumThreads() {
		return numThreads;
	}

	public static void setNumThreads(int numThreads) {
		AppManager.numThreads = numThreads;
	}

	public static int getNumModules() {
		return numModules;
	}

	public static void setNumModules(int numModules) {
		AppManager.numModules = numModules;
	}

	public static int getMaxRow() {
		return maxRow;
	}

	public static void setMaxRow(int maxRow) {
		AppManager.maxRow = maxRow;
	}

	public static int getTimeSleep() {
		return timeSleep;
	}

	public static void setTimeSleep(int timeSleep) {
		AppManager.timeSleep = timeSleep;
	}

	public static long getMinTimeDb() {
		return minTimeDb;
	}

	public static void setMinTimeDb(long minTimeDb) {
		AppManager.minTimeDb = minTimeDb;
	}

	public static HashMap getLoggerDbMap() {
		return loggerDbMap;
	}

	public static void setLoggerDbMap(HashMap loggerDbMap) {
		AppManager.loggerDbMap = loggerDbMap;
	}

	public static long[] getTimesDbLevel() {
		return timesDbLevel;
	}

	public static void setTimesDbLevel(long[] timesDbLevel) {
		AppManager.timesDbLevel = timesDbLevel;
	}

	public static long[] getTimesSmswsLevel() {
		return timesSmswsLevel;
	}

	public static void setTimesSmswsLevel(long[] timesSmswsLevel) {
		AppManager.timesSmswsLevel = timesSmswsLevel;
	}

	public static HashMap getLoggerSmswsMap() {
		return loggerSmswsMap;
	}

	public static void setLoggerSmswsMap(HashMap loggerSmswsMap) {
		AppManager.loggerSmswsMap = loggerSmswsMap;
	}

	public static ArrayList<String> getListAgent() {
		return listAgent;
	}

	public static void setListAgent(ArrayList<String> listAgent) {
		AppManager.listAgent = listAgent;
	}

	public static Mailer getMail() {
		return mail;
	}

	public static void setMail(Mailer mail) {
		AppManager.mail = mail;
	}

	public static String getSendTime() {
		return sendTime;
	}

	public static void setSendTime(String sendTime) {
		AppManager.sendTime = sendTime;
	}

	public static int getRetrySentCount() {
		return retrySentCount;
	}

	public static void setRetrySentCount(int retrySentCount) {
		AppManager.retrySentCount = retrySentCount;
	}

}
