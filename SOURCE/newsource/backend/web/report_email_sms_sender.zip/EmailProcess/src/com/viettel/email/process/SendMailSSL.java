/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.email.process;

/**
 *
 * @author thanhnv75
 */
import com.viettel.email.manager.AppManager;
import com.viettel.email.model.Mailer;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.apache.log4j.Logger;

public class SendMailSSL {

	private Mailer mail = AppManager.getMail();
	private static SendMailSSL instance;

	public static SendMailSSL getInstance() {
		synchronized (SendMailSSL.class) {
			if (instance == null) {
				instance = new SendMailSSL();
			}
		}
		return instance;
	}

	private static final Logger logger = Logger.getLogger(SendMailSSL.class);

	public int send(String subject, String content, String sendTo, String sendCc) {
		int result = 0;

		String MAIL_SMTP_CONNECTIONTIMEOUT = "mail.smtp.connectiontimeout";
		String MAIL_SMTP_TIMEOUT = "mail.smtp.timeout";
		String MAIL_SMTP_WRITETIMEOUT = "mail.smtp.writetimeout";
		String MAIL_SOCKET_TIMEOUT = mail.getSocketTimeout();

  // Set a fixed timeout of 60s for all operations -
		// the default timeout is "infinite"
		
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.viettel.com.vn");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.socketFactory.class",
			"javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");
		
		//set time out sending mail
		props.put(MAIL_SMTP_CONNECTIONTIMEOUT, MAIL_SOCKET_TIMEOUT);
		props.put(MAIL_SMTP_TIMEOUT, MAIL_SOCKET_TIMEOUT);
		props.put(MAIL_SMTP_WRITETIMEOUT, MAIL_SOCKET_TIMEOUT);

		Session session = Session.getDefaultInstance(props,
			new javax.mail.Authenticator() {
				@Override
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(mail.getEmailSend(), mail.getPassWord());
				}
			});

		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(mail.getEmailSend()));
			message.setRecipients(Message.RecipientType.TO,
				InternetAddress.parse(sendTo));
			if (!"".equals(sendCc) && sendCc != null) {
				message.setRecipients(Message.RecipientType.CC,
					InternetAddress.parse(sendCc));
			}
			message.setSubject(subject);
			message.setText(content);

			Transport.send(message);
			result = 1;

		} catch (MessagingException e) {
			logger.error(e.getMessage(), e);
		}
		
//		// hard code test
//		result=1;
		return result;
	}
}
