/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.email.database;

import com.viettel.pool.connection.OracleConnection;
import com.viettel.pool.connection.TimestenConnection;
import com.viettel.cluster.agent.integration.Record;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.apache.log4j.Logger;
import com.viettel.email.manager.AppManager;
import com.viettel.email.model.EmailSendQueue;
import com.viettel.email.model.TimeToRun;

/**
 * @see GetConnection
 * @author THANHNV75
 */
public class DbAdapter {

	private static final Logger logger = Logger.getLogger(DbAdapter.class);
	private TimestenConnection connection;
	private int dbRetry;
	private static final String SQL_INSERT_EMAIL_SEND_HIS = "insert into "
		+ "email_send_his(subject, content, send_to, send_cc, sent_time,"
		+ " status,node_name,cluster_name,receive_time, is_spam, retry_sent_count, app_id) "
		+ "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	private static final String SQL_DELETE_EMAIL_SEND_QUEUE = "delete from email_send_queue where id = ?";
	private static final String SQL_CHECK_CONNECTION = "select 1 as data from dual";
	private static final String SQL_UPDATE_RETRY = "update email_send_queue set retry_sent_count = retry_sent_count+1 where id = ?";

	private static int queryTimeout = 30000; // Time out query
	private static int timeBreak = 0;
	private static DbAdapter instance;

	public static int getQueryTimeout() {
		return queryTimeout;
	}

	public static void setQueryTimeout(int queryTimeout) {
		DbAdapter.queryTimeout = queryTimeout;
	}

	public static int getTimeBreak() {
		return timeBreak;
	}

	public static void setTimeBreak(int timeBreak) {
		DbAdapter.timeBreak = timeBreak;
	}

	public static DbAdapter getInstance() {
		if (instance == null) {
			logger.error("Datasource must be initialized!");
		}
		return instance;
	}

	private DbAdapter(String configPath, int dbRetry) {
		try {
			this.connection = (TimestenConnection) OracleConnection.getInstance(configPath);
			this.dbRetry = dbRetry;
		} catch (Exception e) {
			logger.error("Initialize database connection failed.", e);
		}
	}

	public static void init(String configPath, Integer dbRetry) {
		synchronized (DbAdapter.class) {
			if (instance != null) {
				return;
			}
			instance = new DbAdapter(configPath, dbRetry);
		}
	}

	/**
	 * Update retry number when sender error
	 *
	 * @param listMt
	 * @return
	 */
	public int[] updateRetry(List<EmailSendQueue> listMt) {
		int[] result = null;
		int retry = 0;

		while (null == result && retry <= this.dbRetry) {
			if (retry > 0) {
				logger.info("updateRetry retry " + retry);
			}
			result = this.pUpdateRetry(listMt);
			retry++;
		}
		return result;
	}

	/**
	 * update product code of subscriber
	 *
	 * @param listSubscriber list subscriber to update
	 * @return null if update error else return array record updated
	 */
	private int[] pUpdateRetry(List<EmailSendQueue> listMt) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet set = null;
		int[] result;

		try {
			conn = this.connection.getConnection();
			if (null == conn) {
				logger.error("pUpdateRetry get connection null");
				return null;
			}
			stmt = this.connection.getPrepared(conn, SQL_UPDATE_RETRY);
			for (EmailSendQueue mtRecord : listMt) {
				stmt.setLong(1, mtRecord.getID());
				stmt.addBatch();
			}
			result = stmt.executeBatch();
//			conn.commit();
			logger.info("update retry successful with: " + listMt.size());
			return result;
		} catch (Exception ex) {
			logger.error("pUpdateRetry error", ex);
			return null;
		} finally {
			this.connection.close(set, "pUpdateRetry");
			this.connection.close(stmt, "pUpdateRetry");
			this.connection.close(conn, "pUpdateRetry");

		}
	}

	public int[] deleteEmail(List<Long> listMtId) {
		int[] result = null;
		int retry = 0;

		while (null == result && retry <= this.dbRetry) {
			if (retry > 0) {
				logger.info("deleteEmail retry " + retry);
			}
			result = this.pDeleteEmail(listMtId);
			retry++;
		}
		return result;
	}

	private int[] pDeleteEmail(List<Long> listMtId) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet set = null;
		int[] result;

		try {
			conn = this.connection.getConnection();
			if (null == conn) {
				logger.error("pDeleteEmail get connection null");
				return null;
			}
			stmt = this.connection.getPrepared(conn, SQL_DELETE_EMAIL_SEND_QUEUE);
			for (Long mtId : listMtId) {
				stmt.setLong(1, mtId);
				stmt.addBatch();
			}
			result = stmt.executeBatch();
			logger.info("delete " + listMtId.size() + " record from EMAIL_SEND_QUEUE");
//			conn.commit();
			return result;
		} catch (Exception ex) {
			logger.error("pDeleteEmail error", ex);
			return null;
		} finally {
			this.connection.close(set, "pDeleteEmail");
			this.connection.close(stmt, "pDeleteEmail");
			this.connection.close(conn, "pDeleteEmail");
		}
	}

	public int[] insertEmailSendHis(List<EmailSendQueue> listMt, String nodeName, String clusterName) {
		int[] result = null;
		int retry = 0;

		while (null == result && retry <= this.dbRetry) {
			if (retry > 0) {
				logger.info("insertEmailSendHis retry " + retry);
			}
			result = this.pInsertEmailSendHis(listMt, nodeName, clusterName);
			retry++;
		}
		return result;
	}

	public int[] pInsertEmailSendHis(List<EmailSendQueue> listEmail, String nodeName, String clusterName) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet set = null;
		int[] result;
		try {
			conn = this.connection.getConnection();
			if (null == conn) {
				logger.error("pInsertEmailSendHis get connection null");
				return null;
			}
			stmt = this.connection.getPrepared(conn, SQL_INSERT_EMAIL_SEND_HIS);
			for (EmailSendQueue email : listEmail) {
//				stmt.setLong(1, email.getMailId());
				int i=0;
				stmt.setString(++i, email.getSubject());
				stmt.setString(++i, email.getContent());
				stmt.setString(++i, email.getSendTo());
				stmt.setString(++i, email.getSendCc());
				stmt.setTimestamp(++i, new Timestamp(System.currentTimeMillis()));
				stmt.setInt(++i, email.getStatus());
				stmt.setString(++i, nodeName);
				stmt.setString(++i, clusterName);
				stmt.setTimestamp(++i, email.getReceiveTime());
				stmt.setInt(++i, email.getIsSpam());
				stmt.setInt(++i, email.getRetryNum());
				stmt.setString(++i, email.getAppId());
				stmt.addBatch();
			}
			result = stmt.executeBatch();
			logger.info("insert " + listEmail.size() + " record in MT_HIS");
//			conn.commit();
			return result;
		} catch (Exception ex) {
			logger.error("pInsertEmailSendHis error", ex);
			return null;
		} finally {
			this.connection.close(set, "pInsertEmailSendHis");
			this.connection.close(stmt, "pInsertEmailSendHis");
			this.connection.close(conn, "pInsertEmailSendHis");
		}

	}

	private Date parseDate(String date) {

		try {
			SimpleDateFormat inputParser = new SimpleDateFormat("HH:mm", Locale.US);
			return inputParser.parse(date);
		} catch (java.text.ParseException e) {
			logger.error("error parseDate: ", e);
			return new Date(0);
		}
	}

	private boolean validateTimeToRun(List<TimeToRun> lstTimeToRun) {
		Date date;
		Calendar now = Calendar.getInstance();
		int hour = now.get(Calendar.HOUR_OF_DAY);
		int minute = now.get(Calendar.MINUTE);
		date = parseDate(hour + ":" + minute);
		if (lstTimeToRun.size() > 0) {
			for (TimeToRun time : lstTimeToRun) {
				if (time.getStartTime().before(date) && time.getEndTime().after(date)) {
					return true;
				}
			}
		}

		return false;
	}

	public List<Record> getRecords(String sql) {
		ResultSet rs = null;
		PreparedStatement pre = null;
		Connection conn = null;
		List<Record> lst = new ArrayList<Record>();
		//yada yada
		try {
			conn = this.connection.getConnection();
			if (conn == null) {
				logger.error("Conection is null");
				return null;
			}
			pre = this.connection.getPrepared(conn, sql);
			rs = pre.executeQuery();
			while (rs.next()) {
				EmailSendQueue email = null;
				//check is_spam
				int isSpam = rs.getInt(EmailSendQueue.IS_SPAM);
				if (isSpam == 1) {
					//check time to send sms
					//check current time to send SMS

					String sendTime = AppManager.getSendTime();
					String[] arrTime = sendTime.split("[|]");
					List<TimeToRun> lstTimeToRun = new ArrayList<>();

					if (arrTime.length > 1) {
						for (String a : arrTime) {
							String[] arrTimeSub = a.split("[-]");

							TimeToRun timeToRun = new TimeToRun();
							timeToRun.setStartTime(parseDate(arrTimeSub[0]));
							timeToRun.setEndTime(parseDate(arrTimeSub[1]));
							lstTimeToRun.add(timeToRun);
						}
					} else {
						String[] arrTimeSub = sendTime.split("[-]");
						TimeToRun timeToRun = new TimeToRun();
						timeToRun.setStartTime(parseDate(arrTimeSub[0]));
						timeToRun.setEndTime(parseDate(arrTimeSub[1]));
						lstTimeToRun.add(timeToRun);
					}
					if (validateTimeToRun(lstTimeToRun)) {
						try {
							email = new EmailSendQueue();
							email.setMailId(rs.getLong(EmailSendQueue.ID_DB));
							email.setAppId(rs.getString(EmailSendQueue.APP_ID));
							email.setSubject(rs.getString(EmailSendQueue.SUBJECT));
							email.setContent(rs.getString(EmailSendQueue.CONTENT));
							email.setIsSpam(rs.getInt(EmailSendQueue.IS_SPAM));
							email.setRetryNum(rs.getInt(EmailSendQueue.RETRY_SENT_COUNT));
							email.setSendCc(rs.getString(EmailSendQueue.SEND_CC));
							email.setReceiveTime(rs.getTimestamp(EmailSendQueue.RECEIVE_TIME));
							email.setSendTo(rs.getString(EmailSendQueue.SEND_TO));
						} catch (Exception ex) {
							logger.error("GET EMAIL error: ", ex);
							email = null;
						}
					}
				} else {
					try {
						email = new EmailSendQueue();
						email.setMailId(rs.getLong(EmailSendQueue.ID_DB));
						email.setAppId(rs.getString(EmailSendQueue.APP_ID));
						email.setSubject(rs.getString(EmailSendQueue.SUBJECT));
						email.setContent(rs.getString(EmailSendQueue.CONTENT));
						email.setIsSpam(rs.getInt(EmailSendQueue.IS_SPAM));
						email.setRetryNum(rs.getInt(EmailSendQueue.RETRY_SENT_COUNT));
						email.setSendCc(rs.getString(EmailSendQueue.SEND_CC));
						email.setReceiveTime(rs.getTimestamp(EmailSendQueue.RECEIVE_TIME));
						email.setSendTo(rs.getString(EmailSendQueue.SEND_TO));
					} catch (Exception ex) {
						logger.error("GET EMAIL error: ", ex);
						email = null;
					}
				}

				if (email != null) {
					lst.add(email);
				}
			}
		} catch (Exception ex) {
			logger.error("ERROR: ", ex);
		} finally {
			this.connection.close(rs, "getMailer");
			this.connection.close(pre, "getMailer");
			this.connection.close(conn, "getMailer");
		}
		return lst;
	}

	public int CheckDatabase() {
		ResultSet rs = null;
		PreparedStatement pre = null;
		Connection conn = null;
		try {
			conn = this.connection.getConnection();
			if (conn == null) {
				return 0;
			}
			pre = this.connection.getPrepared(conn, SQL_CHECK_CONNECTION);
			rs = pre.executeQuery();
			int data = -1;
			while (rs.next()) {
				data = rs.getInt("DATA");
				break;
			}
			if (data != -1) {
				return 1;
			}
			return 0;
		} catch (SQLException ex) {
			logger.error("ERROR CHECK DB ", ex);
		} catch (Exception ex) {
			logger.error("ERROR CHECK DB ", ex);
		} finally {
			this.connection.close(rs, "checkDatabase");
			this.connection.close(pre, "checkDatabase");
			this.connection.close(conn, "checkDatabase");
		}
		return 0;
	}

}
