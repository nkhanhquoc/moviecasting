/*
 * Copyright 2011 Viettel Telecom. All rights reserved.
 * VIETTEL PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.viettel.Main;

import com.viettel.mmserver.base.ProcessManager;
import com.viettel.email.manager.AppManager;

/**
 * Start, Stop cac tien trinh
 *
 * @author TungTT
 * @version 1.0
 * @since 01-03-2011
 */
public class ScanProcessManager {

    public int idManager;
    private AppManager manager;
    private static ScanProcessManager instance;

    public ScanProcessManager() throws Exception {
        manager = new AppManager() {
        };
    }

    public static ScanProcessManager getInstance() throws Exception {
        synchronized (ScanProcessManager.class) {
            if (instance == null) {
                instance = new ScanProcessManager();
            }
        }

        return instance;
    }

    public void start() {

        ProcessManager.getInstance().getMmProcess(manager.getId()).start();
    }

    public void stop() {

        ProcessManager.getInstance().getMmProcess(manager.getId()).stop();
    }
}
