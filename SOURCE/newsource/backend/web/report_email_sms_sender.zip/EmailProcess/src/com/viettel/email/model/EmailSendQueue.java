/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.email.model;

import com.viettel.cluster.agent.integration.Record;
import java.sql.Timestamp;

/**
 *
 * @author thanhnv75
 */
public class EmailSendQueue implements Record  {
	
	
	public static final String ID_DB = "id";
    public static final String SUBJECT = "subject";
    public static final String CONTENT = "content";
    public static final String SEND_TO = "send_to";
    public static final String SEND_CC = "send_cc";
    public static final String RETRY_SENT_COUNT = "retry_sent_count";
    public static final String RECEIVE_TIME = "receive_time";
    public static final String APP_ID = "app_id";
	public static final String IS_SPAM= "is_spam";
	
    private String subject;
    private String content;
	private String sendTo;
	private String sendCc;
    private int retryNum;
    private int status;
    private Timestamp receiveTime;
    private String appId;
	private long mailId;
	private int isSpam;
	
	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getSendTo() {
		return sendTo;
	}

	public void setSendTo(String sendTo) {
		this.sendTo = sendTo;
	}


	public int getRetryNum() {
		return retryNum;
	}

	public void setRetryNum(int retryNum) {
		this.retryNum = retryNum;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Timestamp getReceiveTime() {
		return receiveTime;
	}

	public void setReceiveTime(Timestamp receiveTime) {
		this.receiveTime = receiveTime;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public long getMailId() {
		return mailId;
	}

	public void setMailId(long mailId) {
		this.mailId = mailId;
	}

	public int getIsSpam() {
		return isSpam;
	}

	public void setIsSpam(int isSpam) {
		this.isSpam = isSpam;
	}

	public String getSendCc() {
		return sendCc;
	}

	public void setSendCc(String sendCc) {
		this.sendCc = sendCc;
	}

	@Override
	public long getID() {
		return mailId;
	}
}
