/*
 * Copyright 2011 Viettel Telecom. All rights reserved.
 * VIETTEL PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.viettel.Main;

import com.viettel.mmserver.base.ProcessManager;
import com.viettel.mmserver.base.ProcessThreadMX;
import java.util.ArrayList;
import com.viettel.email.manager.AppManager;
import org.openide.util.Exceptions;
import com.viettel.email.model.ProcessInfo;

/**
 * Quan ly cac tien trinh gui email
 * @author ThanhNV75
 * @version 1.0
 * @since 2017
 */
public class ProcessEmailManager extends ProcessThreadMX {

    public static final String name = "Mailer";
    private int idThread[];
//    public static HashMap listDbInfo;

    public ProcessEmailManager(String appId) throws Exception {
        super(ProcessEmailManager.name);
//        ProcessManager.getInstance().addMmProcess(this);
        registerAgent(AppManager.getAppId() + ":type=" + ProcessEmailManager.name);

//        listDbInfo = getListDb(Config.configDir + File.separator + "database.conf");

        // Init threads
        ArrayList<ProcessInfo> listProcess = getListProcessInfo();
        idThread = new int[listProcess.size()];
        for (int i = 0; i < listProcess.size(); i++) {
            ProcessEmail pro = new ProcessEmail(listProcess.get(i).getName(), listProcess.get(i).getModuleId());
            idThread[i] = pro.getId();
        }
    }

    /**
     * Khoi tao thong tin cac tien trinh
     * @return
     * @throws Exception 
     */
    private ArrayList<ProcessInfo> getListProcessInfo() throws Exception {
        ArrayList<ProcessInfo> listProcess = new ArrayList<ProcessInfo>();
        for (int i = 0; i < AppManager.getNumModules(); i++) {
            for (int j = 0; j < AppManager.getNumThreads(); j++) {
                listProcess.add(new ProcessInfo("Mailer.Module" + i + ".Thread-" + j, i));
            }
        }
        return listProcess;
    }
    @Override
    protected void process() {
        try {
            Thread.sleep(10000);
        } catch (InterruptedException ex) {
            Exceptions.printStackTrace(ex);
        }
    }

    @Override
    public void start() {
        for (int i = 0; i < idThread.length; i++) {
            ProcessManager.getInstance().getMmProcess(idThread[i]).start();
        }
        super.start();
        logger.info("+++ SYSTEM MAILER STARTED  +++");
    }

    @Override
    public void stop() {
        for (int i = 0; i < idThread.length; i++) {
            ProcessManager.getInstance().getMmProcess(idThread[i]).stop();
        }

        super.stop();
        logger.info("+++ SYSTEM MAILER STOPPED  +++");
    }
}
