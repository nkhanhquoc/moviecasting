/*
 * @Stop.java	version 2.1     01/03/2010
 *
 * Copyright 2010 Viettel Telecom. All rights reserved.
 * VIETTEL PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.viettel.Main;

/**
 * Stop
 * @author TungTT
 * @version 1.0
 * @since 01-03-2011
 */
public class Stop {

    public static void main(String[] args) throws Exception {
        ScanProcessManager.getInstance().stop();
    }
}
